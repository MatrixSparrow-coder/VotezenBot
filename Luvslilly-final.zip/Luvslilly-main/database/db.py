from datetime import datetime, timezone
from motor.motor_asyncio import AsyncIOMotorClient
from config import MONGO_URI, DB_NAME

if not MONGO_URI:
    raise RuntimeError("MONGO_URI is required")

client = AsyncIOMotorClient(MONGO_URI, serverSelectionTimeoutMS=10000)
db = client[DB_NAME]

users = db.users
admins = db.admins
channels = db.channels
giveaways = db.giveaways
participants = db.participants
voters = db.voters
settings = db.settings
access_sessions = db.access_sessions
setup_sessions = db.setup_sessions
exports = db.exports
referrals = db.referrals

async def ensure_indexes():
    # NOTE: _id is always unique by default in MongoDB — creating an explicit
    # unique index on it is invalid and raises OperationFailure (code 197).
    # So users/admins/access_sessions/setup_sessions need no extra index here.
    await channels.create_index([("owner_id", 1), ("channel_id", 1)], unique=True)
    await giveaways.create_index([("channel_id", 1), ("status", 1)])
    await giveaways.create_index([("hoster_id", 1), ("status", 1)])
    await giveaways.create_index("end_at")
    await giveaways.create_index([("status", 1), ("reminder_sent", 1), ("end_at", 1)])
    await participants.create_index([("giveaway_id", 1), ("user_id", 1)], unique=True)
    await participants.create_index([("giveaway_id", 1), ("vote_count", -1)])
    await participants.create_index([("giveaway_id", 1), ("number", 1)])
    await participants.create_index([("giveaway_id", 1), ("referral_count", -1)])
    await voters.create_index([("giveaway_id", 1), ("voter_id", 1)], unique=True)
    await voters.create_index([("giveaway_id", 1), ("participant_id", 1)])
    # One referral credit per referred user per giveaway — this is what
    # stops a referral link from being farmed by rejoining/re-checking.
    await referrals.create_index([("giveaway_id", 1), ("referred_id", 1)], unique=True)

async def track_user(user):
    await users.update_one(
        {"_id": user.id},
        {"$set": {"username": user.username, "first_name": user.first_name, "last_name": user.last_name},
         "$setOnInsert": {"created_at": datetime.now(timezone.utc), "banned": False}},
        upsert=True,
    )

async def is_banned(uid):
    doc = await users.find_one({"_id": uid}, {"banned": 1})
    return bool(doc and doc.get("banned"))

async def get_role(uid, owner_id):
    if uid == owner_id:
        return "owner"
    doc = await admins.find_one({"_id": uid})
    return doc.get("role") if doc else None

async def effective_hoster(uid, owner_id):
    sess = await access_sessions.find_one({"_id": uid})
    if sess and (await get_role(uid, owner_id)) in ("owner", "sadmin"):
        return sess["giveaway_id"], sess["hoster_id"]
    return None, uid
