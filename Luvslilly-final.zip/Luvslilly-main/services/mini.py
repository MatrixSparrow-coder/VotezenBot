from pyrogram.errors import MessageNotModified
from utils.fonts import heavy_channel, small_caps
from utils.text import escape_md
from utils.ui import mini_join
from database.db import participants


def mini_text(g, people):
    lines = [
        f"🎲 {heavy_channel('MINI GIVEAWAY LIVE')} 🎲",
        "✦ ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯ ✦",
        "",
        f"⏳ {small_caps('ends')}: {g.get('end_display', 'manual')}",
        f"🏆 {small_caps('winners')}: {g.get('winner_count', 1)}",
        f"👥 {small_caps('entries')}: {len(people)}",
        "",
    ]
    if not people:
        lines.append("👀 " + small_caps("no one yet — be the first!"))
    else:
        def who(p):
            name = escape_md(p.get('name', 'User'))
            uid = p.get('user_id')
            return f"[{name}](tg://user?id={uid})" if uid else name
        rows = [f"👤 #{p.get('number')} — {who(p)}" for p in people]
        if sum(len(x) + 1 for x in rows) + len("\n".join(lines)) > 3800:
            keep = max(1, len(rows) // 2)
            lines.extend(rows[:keep])
            lines.append(f"...and {len(rows) - keep} more")
        else:
            lines.extend(rows)
    lines += ["", "✦ ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯ ✦", "👉 " + small_caps("tap below to join!")]
    return "\n".join(lines)


async def refresh_live(app, g):
    people = await participants.find({"giveaway_id": g["_id"]}).sort("number", 1).to_list(length=None)
    text = mini_text(g, people)
    kb = mini_join(f"https://t.me/{g['bot_username']}?start=minigiv_{g['_id']}")
    mid = g.get("live_message_id")
    if mid:
        try:
            await app.edit_message_text(g["channel_id"], mid, text, reply_markup=kb)
            return mid
        except MessageNotModified:
            return mid
        except Exception:
            pass  # message was deleted or otherwise unrecoverable — fall through and repost
    msg = await app.send_message(g["channel_id"], text, reply_markup=kb)
    return msg.id
    
