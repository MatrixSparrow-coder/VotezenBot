from datetime import datetime, timezone
from database.db import giveaways, participants, referrals
from utils.fonts import heavy_channel, small_caps
from utils.text import escape_md
from config import BOT_USERNAME


def referral_link(gid, referrer_id):
    return f"https://t.me/{BOT_USERNAME}?start=ref_{gid}_{referrer_id}"


def _board_text(g, top):
    lines = [
        f"⌬ {heavy_channel('REFERRAL LEADERBOARD')} ⌬",
        "✦ ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯ ✦",
        "",
        f"{small_caps('giveaway')} #{g['_id']} • {g.get('channel_title','')}",
        "",
    ]
    if not top:
        lines.append(small_caps("no referrals yet — be the first to invite someone!"))
    else:
        for i, p in enumerate(top, 1):
            name = escape_md(p.get("name", "User"))
            uid = p.get("user_id")
            who = f"[{name}](tg://user?id={uid})" if uid else name
            lines.append(f"{i}. {who} — {p.get('referral_count', 0)} {small_caps('referrals')}")
    lines += ["", "✦ ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯ ✦", small_caps("join the giveaway, then share your personal link to climb this board.")]
    return "\n".join(lines)


async def refresh_referral_board(app, gid):
    """Posts (or edits) the referral leaderboard in the GIVEAWAY channel
    (g['channel_id']) — the same channel /host posts entries/votes to.
    The referral_channel_id is ONLY used to verify a new user joined it
    (see credit_referral / handlers.giveaway.referral_start) — it never
    gets a post of its own, unless it happens to BE the giveaway channel."""
    return  # referral system temporarily disabled
    g = await giveaways.find_one({"_id": gid})
    if not g or not g.get("referral_channel_id"):
        return
    top = await participants.find(
        {"giveaway_id": gid, "referral_count": {"$gt": 0}}
    ).sort("referral_count", -1).to_list(length=10)
    text = _board_text(g, top)
    mid = g.get("referral_message_id")
    if mid:
        try:
            await app.edit_message_text(g["channel_id"], mid, text)
            return
        except Exception:
            pass  # message may have been deleted — fall through and repost
    try:
        msg = await app.send_message(g["channel_id"], text)
        await giveaways.update_one({"_id": gid}, {"$set": {"referral_message_id": msg.id}})
    except Exception:
        pass


async def credit_referral(app, gid, referrer_id, referred_id):
    """Credits one referral to referrer_id for giveaway gid, once per
    referred_id (enforced by a unique index — see database/db.py). Returns
    True only if this call actually newly credited it."""
    return False  # referral system temporarily disabled
    if referrer_id == referred_id:
        return False
    g = await giveaways.find_one({"_id": gid, "status": "active"})
    if not g or not g.get("referral_channel_id"):
        return False
    referrer_p = await participants.find_one({"giveaway_id": gid, "user_id": referrer_id})
    if not referrer_p:
        return False  # only real participants of THIS giveaway can earn referral credit
    try:
        await referrals.insert_one({
            "giveaway_id": gid,
            "referrer_id": referrer_id,
            "referred_id": referred_id,
            "created_at": datetime.now(timezone.utc),
        })
    except Exception:
        return False  # duplicate key -> this referred user already counted once
    await participants.update_one({"_id": referrer_p["_id"]}, {"$inc": {"referral_count": 1}})
    await refresh_referral_board(app, gid)
    return True
