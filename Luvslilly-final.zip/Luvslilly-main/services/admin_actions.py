import asyncio
from pyrogram.errors import FloodWait
from database.db import users, admins
from services.commands import apply_scope


async def set_ban(uid, banned):
    await users.update_one({"_id": uid}, {"$set": {"banned": banned}}, upsert=True)


async def set_admin_role(app, uid, role):
    """role is 'admin', 'sadmin', or None to remove."""
    if role is None:
        await admins.delete_one({"_id": uid})
    else:
        await admins.update_one({"_id": uid}, {"$set": {"role": role}}, upsert=True)
    await apply_scope(app, uid, role)


async def do_broadcast(app, text):
    """Legacy text-only broadcast, used by the /broadcast <text> quick command."""
    ok = fail = 0
    async for u in users.find({}, {"_id": 1}):
        try:
            await app.send_message(u["_id"], text)
            ok += 1
        except FloodWait as e:
            await asyncio.sleep(e.value)
            try:
                await app.send_message(u["_id"], text)
                ok += 1
            except Exception:
                fail += 1
        except Exception:
            fail += 1
        await asyncio.sleep(0.05)  # light pacing so we don't trigger FloodWait as often
    return ok, fail


async def do_broadcast_copy(app, message):
    """Copies ANY message type (text, sticker, photo, video, GIF, document...)
    to every known user. Used by the panel's 📢 Broadcast button flow so
    stickers/media are supported, not just plain text."""
    ok = fail = 0
    async for u in users.find({}, {"_id": 1}):
        try:
            await message.copy(u["_id"])
            ok += 1
        except FloodWait as e:
            await asyncio.sleep(e.value)
            try:
                await message.copy(u["_id"])
                ok += 1
            except Exception:
                fail += 1
        except Exception:
            fail += 1
        await asyncio.sleep(0.05)
    return ok, fail
