import asyncio
from datetime import datetime, timezone, timedelta
from database.db import giveaways
from services.lifecycle import end_giveaway, cleanup
from config import REMINDER_MINUTES

async def scheduler_loop(app):
    while True:
        try:
            now=datetime.now(timezone.utc)
            due=await giveaways.find({"status":"active","end_at":{"$ne":None,"$lte":now}}).to_list(length=100)
            for g in due:
                await end_giveaway(app,g["_id"])
            reminders=await giveaways.find({
                "status":"active","end_at":{"$ne":None},
                "reminder_sent":{"$ne":True},
                "end_at":{"$lte":now+timedelta(minutes=REMINDER_MINUTES),"$gt":now}
            }).to_list(length=100)
            for g in reminders:
                try:
                    await app.send_message(g["channel_id"],"⏰ "+("ᴏɴᴇ ʜᴏᴜʀ ʟᴇғᴛ! ʟᴀsᴛ ᴄʜᴀɴᴄᴇ ᴛᴏ ᴊᴏɪɴ."))
                except Exception:
                    pass
                await giveaways.update_one({"_id":g["_id"]},{"$set":{"reminder_sent":True}})
            await cleanup(app)
        except Exception as e:
            print("scheduler:",repr(e))
        await asyncio.sleep(30)
