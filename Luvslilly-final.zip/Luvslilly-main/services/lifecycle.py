from datetime import datetime, timezone, timedelta
from database.db import giveaways, participants, voters
from config import CLEANUP_AFTER_DAYS
from services.results import unique_random_winners, main_channel_result, mini_channel_result, hoster_result
from services.export import make_export
from utils.ui import download_export
from utils.fonts import small_caps

async def end_giveaway(app, gid, actor_id=None):
    g = await giveaways.find_one_and_update(
        {"_id": gid, "status": "active"},
        {"$set": {"status":"ended","ended_at":datetime.now(timezone.utc)}}
    )
    if not g:
        return False
    ps = await participants.find({"giveaway_id":gid}).sort("vote_count",-1).to_list(length=None)
    winners = []
    if g["type"] == "mini":
        winners = unique_random_winners(ps, int(g.get("winner_count",1)))
        text = mini_channel_result(gid, winners)
    else:
        text = main_channel_result(gid, ps)
    try:
        if g["type"] == "mini" and g.get("live_message_id"):
            await app.send_message(g["channel_id"], text, reply_to_message_id=g["live_message_id"])
        else:
            await app.send_message(g["channel_id"], text)
    except Exception:
        pass
    try:
        text = (
            hoster_result(gid,g,ps,winners)
            + f"\n\n{small_caps('giveaway data will be deleted in')} {CLEANUP_AFTER_DAYS} {small_caps('days.')}\n"
            + small_caps("download it now if you need the full record.")
        )
        await app.send_message(g["hoster_id"], text, reply_markup=download_export(gid))
    except Exception:
        pass
    await giveaways.update_one({"_id":gid},{"$set":{"delete_at":datetime.now(timezone.utc)+timedelta(days=CLEANUP_AFTER_DAYS)}})
    await _revert_hoster_menu(app, g["hoster_id"])
    return True

async def _revert_hoster_menu(app, hoster_id):
    from config import OWNER_ID
    from services.commands import revert_hoster_scope
    try:
        await revert_hoster_scope(app, hoster_id, OWNER_ID)
    except Exception:
        pass

async def cancel_giveaway(app, gid):
    g = await giveaways.find_one_and_update(
        {"_id":gid,"status":"active"},
        {"$set":{"status":"cancelled","cancelled_at":datetime.now(timezone.utc),
                 "delete_at":datetime.now(timezone.utc)+timedelta(days=CLEANUP_AFTER_DAYS)}}
    )
    if not g:
        return False
    ps = await participants.find({"giveaway_id":gid}).to_list(length=None)
    for p in ps:
        if p.get("message_id"):
            try:
                await app.delete_messages(g["channel_id"], p["message_id"])
            except Exception:
                pass
    if g.get("live_message_id"):
        try:
            await app.delete_messages(g["channel_id"], g["live_message_id"])
        except Exception:
            pass
    await app.send_message(g["hoster_id"], f"{small_caps('giveaway cancelled.')}\nID: {gid}")
    await _revert_hoster_menu(app, g["hoster_id"])
    return True

async def cleanup(app):
    now=datetime.now(timezone.utc)
    docs=await giveaways.find({"delete_at":{"$lte":now},"status":{"$in":["ended","cancelled"]}}).to_list(length=100)
    for g in docs:
        gid=g["_id"]
        await participants.delete_many({"giveaway_id":gid})
        await voters.delete_many({"giveaway_id":gid})
        await giveaways.update_one({"_id":gid},{"$set":{"cleaned":True},"$unset":{"delete_at":""}})

async def export_to_user(app, gid, user_id):
    data=await make_export(gid)
    if not data:
        return False
    data.name=f"VoteZenBot_{gid}.txt"
    await app.send_document(user_id, data, caption=small_caps(f"giveaway data • {gid}"))
    return True
