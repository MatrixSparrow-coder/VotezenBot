import logging
from pyrogram.errors import MessageNotModified
from utils.fonts import heavy_channel, small_caps
from utils.text import escape_md
from utils.ui import vote
from utils.images import placeholder_image
from database.db import participants, settings
from config import FALLBACK_PFP_URL

log = logging.getLogger(__name__)


def entry_caption(p, header="NEW ENTRY"):
    name = escape_md(p.get('name', 'User'))
    uid = p.get('user_id')
    who = f"[{name}](tg://user?id={uid})" if uid else name
    votes = p.get('vote_count', 0)
    lines = [
        f"⌬ {heavy_channel(header)} ⌬",
        "✦ ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯ ✦",
        "",
        f"👤 {small_caps('entrant')}",
        f"   ⟶ {who}",
        "",
        f"🗳️ {small_caps('votes')}",
        f"   ⟶ {votes}",
    ]
    if p.get("caption"):
        lines += ["", f"📝 {small_caps('caption')}", f"   ⟶ {escape_md(p['caption'])}"]
    lines += ["", "✦ ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯ ✦", f"⟡ {small_caps('tap vote to support')} ⟡"]
    return "\n".join(lines)


async def entry_photo(app):
    """Every entry post uses the SAME fixed image (not the participant's own
    profile photo) — set it once with /entrypic, or via FALLBACK_PFP_URL."""
    try:
        s = await settings.find_one({"_id": "entrypic"})
        if s and s.get("file_id"):
            return s["file_id"]
    except Exception:
        log.exception("entrypic lookup failed")
    if FALLBACK_PFP_URL:
        return FALLBACK_PFP_URL
    # Same seed for everyone → identical placeholder image for all entries.
    return placeholder_image("VOTEZEN")


async def post_entry(app, giveaway, participant):
    caption = entry_caption(participant)
    keyboard = vote(giveaway["_id"], participant["user_id"], participant.get("vote_count", 0))
    photo = await entry_photo(app)
    try:
        msg = await app.send_photo(giveaway["channel_id"], photo, caption=caption, reply_markup=keyboard)
    except Exception:
        msg = await app.send_message(giveaway["channel_id"], caption, reply_markup=keyboard)
        await participants.update_one({"_id": participant["_id"]}, {"$set": {"message_id": msg.id, "has_photo": False}})
        return msg
    await participants.update_one({"_id": participant["_id"]}, {"$set": {"message_id": msg.id, "has_photo": True}})
    return msg


async def refresh_entry(app, giveaway, participant):
    caption = entry_caption(participant)
    keyboard = vote(giveaway["_id"], participant["user_id"], participant.get("vote_count", 0))
    mid = participant.get("message_id")
    if not mid:
        return await post_entry(app, giveaway, participant)
    try:
        if participant.get("has_photo"):
            await app.edit_message_caption(giveaway["channel_id"], mid, caption=caption, reply_markup=keyboard)
        else:
            await app.edit_message_text(giveaway["channel_id"], mid, caption, reply_markup=keyboard)
    except MessageNotModified:
        pass
    except Exception:
        return await post_entry(app, giveaway, participant)