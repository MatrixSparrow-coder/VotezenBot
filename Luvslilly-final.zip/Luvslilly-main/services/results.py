import secrets
from utils.fonts import heavy_channel, small_caps
from utils.text import escape_md

def mention(p):
    name = escape_md(p.get('name', 'User'))
    uid = p.get('user_id')
    if not uid:
        return name
    return f"[{name}](tg://user?id={uid})"

def unique_random_winners(items, count):
    pool = list(items)
    result = []
    while pool and len(result) < count:
        result.append(pool.pop(secrets.randbelow(len(pool))))
    return result

def main_channel_result(gid, ranked):
    lines = [f"🏁 {heavy_channel('GIVEAWAY ENDED!')} 🏁", "✦ ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯ ✦", "", f"🔖 {small_caps('giveaway id')}: {gid}", ""]
    if not ranked:
        lines.append("😶 " + small_caps("no entries this time."))
        return "\n".join(lines)
    for i, p in enumerate(ranked[:10], 1):
        medal = {1:"🥇",2:"🥈",3:"🥉"}.get(i, f"{i}.")
        lines.append(f"{medal} {mention(p)} — {p.get('vote_count',0)}")
    lines += ["", "✦ ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯ ✦"]
    return "\n".join(lines)

def mini_channel_result(gid, winners):
    lines = [f"🎉 {heavy_channel('MINI GIVEAWAY WINNERS!')} 🎉", "✦ ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯ ✦", "", f"🔖 {small_caps('giveaway id')}: {gid}", ""]
    if not winners:
        lines.append("😶 " + small_caps("no entries this time."))
        return "\n".join(lines)
    for p in winners:
        lines.append(f"🏆 #{p.get('number')} — {mention(p)}")
    lines += ["", "✦ ⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯ ✦"]
    return "\n".join(lines)

def hoster_result(gid, giveaway, participants, winners=None):
    lines = [
        heavy_channel("RESULTS"),
        "",
        f"{small_caps('giveaway id')}: {gid}",
        f"{small_caps('type')}: {giveaway['type']}",
        f"{small_caps('channel')}: {giveaway.get('channel_title','')}",
        "",
    ]
    if giveaway["type"] == "main":
        if not participants:
            lines.append(small_caps("no participants entered."))
        else:
            for i,p in enumerate(participants[:10],1):
                lines.append(f"{i}. {mention(p)} — {p.get('vote_count',0)} votes")
    else:
        if not winners:
            lines.append(small_caps("no one entered this time."))
        else:
            for p in winners:
                lines.append(f"🏆 #{p.get('number')} — {mention(p)} — ID {p.get('user_id')}")
    return "\n".join(lines)