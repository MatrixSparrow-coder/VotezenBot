from pyrogram.types import BotCommand, BotCommandScopeDefault, BotCommandScopeChat

# Commands EVERY user sees when they type "/" — no host-only or admin-only
# stuff here. A normal participant should never even see /incr, /end, etc.
# exist until they actually host a giveaway.
PUBLIC = [
    BotCommand("start", "Main menu"),
    BotCommand("help", "How it works"),
    BotCommand("addch", "Save a channel"),
    BotCommand("channels", "Your saved channels"),
    BotCommand("delch", "Remove a saved channel"),
    BotCommand("host", "Start a voting giveaway"),
    BotCommand("minigiv", "Start a mini giveaway"),
    BotCommand("mystats", "Your hosted giveaways"),
    BotCommand("leaderboard", "Your rank in an active giveaway"),
]

# Only shown to a user once they actually have a live giveaway — applied via
# apply_hoster_scope() right after /host / /minigiv succeeds, and removed
# again via revert_hoster_scope() once they have no active giveaways left.
HOSTER_ONLY = [
    BotCommand("end", "End your giveaway early"),
    BotCommand("cancel", "Cancel your giveaway"),
    BotCommand("incr", "Add votes to a participant"),
    BotCommand("banp", "Ban a participant"),
    BotCommand("unbanp", "Unban a participant"),
]

ADMIN_EXTRA = PUBLIC + HOSTER_ONLY + [
    BotCommand("admin", "Open admin panel"),
    BotCommand("stats", "Bot-wide stats"),
    BotCommand("current", "All active giveaways"),
]

SADMIN_EXTRA = ADMIN_EXTRA + [
    BotCommand("sadmin", "Open super admin panel"),
    BotCommand("access", "Access a giveaway as staff"),
    BotCommand("exit", "Exit access mode"),
]

OWNER_EXTRA = SADMIN_EXTRA + [
    BotCommand("owner", "Open owner panel"),
    BotCommand("addadmin", "Add an admin"),
    BotCommand("removeadmin", "Remove an admin"),
    BotCommand("saddadmin", "Add a super admin"),
    BotCommand("remsadmin", "Remove a super admin"),
    BotCommand("ban", "Ban a user from the bot"),
    BotCommand("unban", "Unban a user"),
    BotCommand("broadcast", "Broadcast a message to all users"),
    BotCommand("startmedia", "Set the /start banner (photo or video)"),
    BotCommand("entrypic", "Set the fixed entry-post photo"),
    BotCommand("helppdf", "Update the guide PDFs"),
]

_BY_ROLE = {"owner": OWNER_EXTRA, "sadmin": SADMIN_EXTRA, "admin": ADMIN_EXTRA}


async def apply_scope(app, user_id, role):
    """Set a personal command menu for one user by role. role=None resets
    them to the plain public menu (e.g. after being removed as admin)."""
    cmds = _BY_ROLE.get(role, PUBLIC)
    try:
        await app.set_bot_commands(cmds, scope=BotCommandScopeChat(chat_id=user_id))
    except Exception:
        pass


async def apply_hoster_scope(app, user_id, owner_id):
    """Reveal the host-only commands to a plain user the moment they create
    their first active giveaway. No-op for admin/sadmin/owner — they already
    have these commands as part of their role menu."""
    from database.db import get_role
    role = await get_role(user_id, owner_id)
    if role in _BY_ROLE:
        return
    try:
        await app.set_bot_commands(PUBLIC + HOSTER_ONLY, scope=BotCommandScopeChat(chat_id=user_id))
    except Exception:
        pass


async def revert_hoster_scope(app, user_id, owner_id):
    """Hide the host-only commands again once a plain user has no more
    active giveaways left to manage."""
    from database.db import get_role, giveaways
    role = await get_role(user_id, owner_id)
    if role in _BY_ROLE:
        return
    still_hosting = await giveaways.find_one({"hoster_id": user_id, "status": "active"})
    if still_hosting:
        return
    try:
        await app.set_bot_commands(PUBLIC, scope=BotCommandScopeChat(chat_id=user_id))
    except Exception:
        pass


async def sync_all(app, owner_id):
    """Call once at startup: set the public default, refresh every known
    admin/sadmin's personal menu, and re-apply the hoster menu for anyone
    who currently has an active giveaway (in case the bot restarted)."""
    from database.db import admins, giveaways
    try:
        await app.set_bot_commands(PUBLIC, scope=BotCommandScopeDefault())
    except Exception:
        pass
    await apply_scope(app, owner_id, "owner")
    async for a in admins.find({}):
        await apply_scope(app, a["_id"], a.get("role", "admin"))
    # motor's distinct() resolves straight to a plain list, not an async
    # cursor — using `async for` on it crashes with TypeError at startup.
    for hoster_id in await giveaways.distinct("hoster_id", {"status": "active"}):
        await apply_hoster_scope(app, hoster_id, owner_id)