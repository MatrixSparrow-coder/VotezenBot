from pyrogram.enums import ChatMemberStatus

async def is_member(app, channel_id, user_id):
    try:
        member = await app.get_chat_member(channel_id, user_id)
        return member.status in {
            ChatMemberStatus.MEMBER,
            ChatMemberStatus.ADMINISTRATOR,
            ChatMemberStatus.OWNER,
            ChatMemberStatus.RESTRICTED,
        }
    except Exception:
        return False

async def is_channel_admin(app, channel_id, user_id):
    try:
        member = await app.get_chat_member(channel_id, user_id)
        return member.status in {ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER}
    except Exception:
        return False
