from io import BytesIO
from database.db import giveaways, participants, voters

async def make_export(gid):
    g = await giveaways.find_one({"_id": gid})
    if not g:
        return None
    ps = await participants.find({"giveaway_id": gid}).sort("join_at", 1).to_list(length=None)
    vs = await voters.find({"giveaway_id": gid}).sort("created_at", 1).to_list(length=None)

    out = [
        "VOTEZENBOT — GIVEAWAY DATA EXPORT",
        "=" * 72,
        f"Giveaway ID : {gid}",
        f"Type        : {g.get('type')}",
        f"Channel     : {g.get('channel_title')} ({g.get('channel_id')})",
        f"Hoster ID   : {g.get('hoster_id')}",
        f"Created     : {g.get('created_at')}",
        f"Start       : {g.get('start_at')}",
        f"End         : {g.get('end_at')}",
        f"Status      : {g.get('status')}",
        "",
        "PARTICIPANTS",
        "-" * 72,
    ]
    for p in ps:
        out.extend([
            f"User ID       : {p.get('user_id')}",
            f"Name          : {p.get('name')}",
            f"Username      : @{p.get('username')}" if p.get("username") else "Username      : -",
            f"Join time     : {p.get('join_at')}",
            f"Votes         : {p.get('vote_count', 0)}",
            f"Manual votes  : {p.get('manual_votes', 0)}",
            f"Number        : {p.get('number', '-')}",
            f"Caption       : {p.get('caption') or '-'}",
            f"Entry message : {p.get('message_id') or '-'}",
            "",
        ])
    out += ["VOTING RECORDS", "-" * 72]
    for v in vs:
        out.extend([
            f"Voter ID      : {v.get('voter_id')}",
            f"Participant ID: {v.get('participant_id')}",
            f"Created       : {v.get('created_at')}",
            "",
        ])
    return BytesIO(("\n".join(out)).encode("utf-8"))
