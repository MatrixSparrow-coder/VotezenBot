from datetime import datetime, timezone
from pyrogram import filters, ContinuePropagation
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove
from database.db import channels, giveaways, setup_sessions, is_banned
from config import BOT_USERNAME, MAX_SAVED_CHANNELS
from services.membership import is_channel_admin
from utils.fonts import small_caps
from utils.ids import new_giveaway_id
from utils.time import parse_ist, display

# Shown alongside /host — quick persistent access to the three most common
# actions instead of hunting for slash commands. "🔁 Referral System" here
# fires the SAME handler as the one in handlers/hoster.py (Pyrogram matches
# on the button's text, not which keyboard it came from), so it works even
# before a giveaway exists — it'll just say "host one first" if needed.
USER_KB = ReplyKeyboardMarkup([
    ["🎉 Host Giveaway", "🎲 Mini Giveaway"],
    ["🔁 Referral System"],
    ["❌ Close Panel"],
], resize_keyboard=True)


async def begin_flow(app, target, user, typ):
    """target must have .reply_text(). Shared by /host, /minigiv and the
    /start menu buttons. Only ever offers channels the user actually saved
    via /addch — closes the old bypass where /host accepted any channel."""
    if await is_banned(user.id):
        return
    docs = await channels.find({"owner_id": user.id}).sort("title", 1).to_list(length=MAX_SAVED_CHANNELS)
    if not docs:
        return await target.reply_text(small_caps("you have no saved channels yet. use /addch @channel first."))
    await setup_sessions.update_one({"_id": user.id}, {"$set": {"type": typ, "step": "channel", "data": {}}}, upsert=True)
    kb = InlineKeyboardMarkup([[InlineKeyboardButton(c.get("title", "Channel"), callback_data=f"setup_pick:{c['channel_id']}")] for c in docs])
    await target.reply_text(small_caps("choose a channel for this giveaway:"), reply_markup=kb)


def register(app):
    @app.on_message(filters.private & filters.command(["host", "minigiv"]))
    async def begin(app, m):
        typ = "main" if m.command[0].lower() == "host" else "mini"
        await begin_flow(app, m, m.from_user, typ)
        if typ == "main":
            await m.reply_text(small_caps("quick actions 👇"), reply_markup=USER_KB)

    @app.on_message(filters.private & filters.regex("^🎉 Host Giveaway$"))
    async def kb_host(app, m):
        await begin_flow(app, m, m.from_user, "main")

    @app.on_message(filters.private & filters.regex("^🎲 Mini Giveaway$"))
    async def kb_mini(app, m):
        await begin_flow(app, m, m.from_user, "mini")

    @app.on_message(filters.private & filters.regex("^❌ Close Panel$"))
    async def kb_close(_, m):
        # panel.py's own "❌ Close Panel" handler (registered before this
        # module — see main.py) already handles owner/sadmin/admin and stops
        # here; if we're reached at all, this is a non-staff user.
        await m.reply_text(small_caps("panel closed."), reply_markup=ReplyKeyboardRemove())

    @app.on_message(filters.private & filters.text)
    async def conversation(app, m):
        if m.text and m.text.startswith("/"):
            raise ContinuePropagation
        s = await setup_sessions.find_one({"_id": m.from_user.id})
        if not s or s["step"] not in ("start", "end", "winners"):
            raise ContinuePropagation
        step = s["step"]; d = s["data"]; typ = s["type"]
        try:
            if step == "start":
                try: d["start_at"] = parse_ist(m.text).astimezone(timezone.utc)
                except Exception: return await m.reply_text(small_caps("invalid time. use YYYY-MM-DD HH:MM."))
                await setup_sessions.update_one({"_id": m.from_user.id}, {"$set": {"step": "end", "data": d}})
                return await m.reply_text(small_caps("set end time in YYYY-MM-DD HH:MM IST, or skip."),
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⏭️ " + small_caps("skip"), callback_data="setup_skip:end")]]))
            if step == "end":
                try: d["end_at"] = parse_ist(m.text).astimezone(timezone.utc)
                except Exception: return await m.reply_text(small_caps("invalid time. use YYYY-MM-DD HH:MM."))
                if d.get("start_at") and d["end_at"] <= d["start_at"]:
                    return await m.reply_text(small_caps("end time must be after start time."))
                if typ == "mini":
                    await setup_sessions.update_one({"_id": m.from_user.id}, {"$set": {"step": "winners", "data": d}})
                    return await m.reply_text(small_caps("how many winners should be picked?"))
                return await _review(m, d, typ)
            if step == "winners":
                try: n = int(m.text.strip())
                except Exception: n = 0
                if n <= 0: return await m.reply_text(small_caps("winner count must be a positive whole number."))
                d["winner_count"] = n
                return await _review(m, d, typ)
        except Exception:
            await m.reply_text(small_caps("something went wrong. please retry this step."))

    _register_setup_callbacks(app)


async def _review(m, d, typ, user_id=None):
    uid = user_id if user_id is not None else m.from_user.id
    gid = new_giveaway_id()
    d["gid"] = gid
    await setup_sessions.update_one({"_id": uid}, {"$set": {"step": "review", "data": d}})
    text = (f"{small_caps('review')}\n\n"
            f"{small_caps('channel')}: {d.get('channel_title')}\n"
            f"{small_caps('start')}: {display(d.get('start_at'))}\n"
            f"{small_caps('end')}: {display(d.get('end_at'))}")
    if typ == "mini": text += f"\n{small_caps('winners')}: {d['winner_count']}"
    from utils.ui import review
    return await m.reply_text(text, reply_markup=review(gid))


async def create_from_session(app, user_id, session):
    d = session["data"]; typ = session["type"]; gid = d["gid"]
    now = datetime.now(timezone.utc)
    active = await giveaways.find_one({"channel_id": d["channel_id"], "status": "active"})
    if active: return None, "channel already has an active giveaway"
    doc = {"_id": gid, "type": typ, "hoster_id": user_id, "channel_id": d["channel_id"], "channel_title": d["channel_title"],
           "channel_username": d.get("channel_username"), "start_at": d.get("start_at"), "end_at": d.get("end_at"),
           "status": "active", "created_at": now, "reminder_sent": False, "winner_count": d.get("winner_count"),
           "bot_username": BOT_USERNAME, "banned_participants": []}
    await giveaways.insert_one(doc)
    return doc, None


def _register_setup_callbacks(app):
    from datetime import datetime, timezone
    from utils.ui import review
    from services.mini import refresh_live

    @app.on_callback_query(filters.regex(r"^setup_pick:"))
    async def pick_cb(app, q):
        s = await setup_sessions.find_one({"_id": q.from_user.id})
        if not s or s["step"] != "channel":
            return await q.answer(small_caps("this session expired."), show_alert=True)
        channel_id = int(q.data.split(":", 1)[1])
        saved = await channels.find_one({"owner_id": q.from_user.id, "channel_id": channel_id})
        chat = None
        try:
            chat = await app.get_chat(channel_id)
        except Exception:
            if saved and saved.get("username"):
                try:
                    chat = await app.get_chat(f"@{saved['username']}")
                except Exception:
                    chat = None
        if not chat:
            return await q.answer(small_caps("i couldn't access that channel. try /delch then /addch it again."), show_alert=True)
        if not await is_channel_admin(app, chat.id, q.from_user.id):
            return await q.answer(small_caps("you must be an admin in that channel."), show_alert=True)
        bot = await app.get_me()
        if not await is_channel_admin(app, chat.id, bot.id):
            return await q.answer(small_caps("add me as an admin in that channel first."), show_alert=True)
        active = await giveaways.find_one({"channel_id": chat.id, "status": "active"})
        if active:
            return await q.answer(small_caps("this channel already has an active giveaway."), show_alert=True)
        d = s["data"]
        d.update({"channel_id": chat.id, "channel_title": chat.title, "channel_username": chat.username})
        await setup_sessions.update_one({"_id": q.from_user.id}, {"$set": {"step": "start", "data": d}})
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("⏭️ " + small_caps("skip"), callback_data="setup_skip:start")]])
        await q.message.edit_text(small_caps("set start time in YYYY-MM-DD HH:MM IST, or skip."), reply_markup=kb)

    @app.on_callback_query(filters.regex(r"^setup_skip:(start|end)$"))
    async def skip_cb(app, q):
        s = await setup_sessions.find_one({"_id": q.from_user.id})
        if not s: return await q.answer(small_caps("this session expired."), show_alert=True)
        step = q.data.split(":")[1]
        if s["step"] != step:
            return await q.answer()
        if step == "start":
            await setup_sessions.update_one({"_id": q.from_user.id}, {"$set": {"step": "end"}})
            return await q.message.edit_text(small_caps("set end time in YYYY-MM-DD HH:MM IST, or skip."),
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⏭️ " + small_caps("skip"), callback_data="setup_skip:end")]]))
        d = s["data"]; typ = s["type"]
        if typ == "mini":
            await setup_sessions.update_one({"_id": q.from_user.id}, {"$set": {"step": "winners"}})
            return await q.message.edit_text(small_caps("how many winners should be picked?"))
        return await _review(q.message, d, typ, user_id=q.from_user.id)

    @app.on_callback_query(filters.regex(r"^review:"))
    async def review_cb(app, q):
        _, gid, answer = q.data.split(":")
        s = await setup_sessions.find_one({"_id": q.from_user.id})
        if not s or s["data"].get("gid") != gid:
            return await q.answer(small_caps("this session expired."), show_alert=True)
        if answer == "no":
            await setup_sessions.delete_one({"_id": q.from_user.id})
            return await q.message.edit_text(small_caps("cancelled."))
        doc, err = await create_from_session(app, q.from_user.id, s)
        if err: return await q.answer(small_caps(err), show_alert=True)
        await setup_sessions.delete_one({"_id": q.from_user.id})
        if doc["type"] == "mini":
            mid = await refresh_live(app, doc)
            await giveaways.update_one({"_id": gid}, {"$set": {"live_message_id": mid}})
        link = f"https://t.me/{BOT_USERNAME}?start={'participate' if doc['type']=='main' else 'minigiv'}_{gid}"
        await q.message.edit_text(f"{small_caps('giveaway created!')}\n\nID: {gid}\n{small_caps('share link')}:\n{link}")
        # Reveal host-only commands (/end /cancel /incr /banp /unbanp) in this
        # user's own command menu now that they're actually hosting something,
        # and pop up the hoster reply-keyboard for reliable one-tap access.
        from config import OWNER_ID
        from services.commands import apply_hoster_scope
        from handlers.hoster import HOSTER_KB
        await apply_hoster_scope(app, q.from_user.id, OWNER_ID)
        await app.send_message(q.from_user.id, small_caps("hoster menu is ready below 👇"), reply_markup=HOSTER_KB)