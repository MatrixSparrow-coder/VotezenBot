from pyrogram import filters
from database.db import channels
from config import MAX_SAVED_CHANNELS
from utils.fonts import small_caps
from services.membership import is_channel_admin


async def list_channels_text(uid):
    docs = await channels.find({"owner_id": uid}).sort("title", 1).to_list(length=MAX_SAVED_CHANNELS)
    if not docs:
        return small_caps("no saved channels. use /addch <channel>.")
    return small_caps("your saved channels") + "\n\n" + "\n".join(
        f"{i}. {c.get('title','Channel')} • {c['channel_id']}" for i, c in enumerate(docs, 1))


def register(app):
    @app.on_message(filters.private & filters.command("channels"))
    async def list_channels(_, m):
        await m.reply_text(await list_channels_text(m.from_user.id))

    @app.on_message(filters.private & filters.command("addch"))
    async def add(app, m):
        if len(m.command) < 2: return await m.reply_text(small_caps("usage: /addch @channel"))
        if await channels.count_documents({"owner_id": m.from_user.id}) >= MAX_SAVED_CHANNELS:
            return await m.reply_text(small_caps("you can save only 5 channels."))
        try:
            chat = await app.get_chat(m.command[1])
            if str(chat.type).lower().split(".")[-1] != "channel":
                return await m.reply_text(small_caps("that is not a channel."))
            if not await is_channel_admin(app, chat.id, m.from_user.id):
                return await m.reply_text(small_caps("you must be a channel admin."))
            bot = await app.get_me()
            if not await is_channel_admin(app, chat.id, bot.id):
                return await m.reply_text(small_caps("add me as an admin in that channel first."))
            await channels.update_one({"owner_id": m.from_user.id, "channel_id": chat.id},
                {"$set": {"title": chat.title, "username": chat.username}}, upsert=True)
            await m.reply_text(small_caps("channel added."))
        except Exception:
            await m.reply_text(small_caps("i couldn't access that channel."))

    @app.on_message(filters.private & filters.command("delch"))
    async def delete(_, m):
        if len(m.command) < 2: return await m.reply_text(small_caps("usage: /delch <channel_id>. use /channels to see ids."))
        try:
            cid = int(m.command[1])
        except ValueError:
            return await m.reply_text(small_caps("that's not a valid channel id. use /channels to see ids."))
        await channels.delete_one({"owner_id": m.from_user.id, "channel_id": cid})
        await m.reply_text(small_caps("channel removed."))