from datetime import datetime, timezone
from pymongo import ReturnDocument
from pyrogram import filters, ContinuePropagation
from pyrogram.types import CallbackQuery
from database.db import giveaways, participants, voters, users, referrals
from services.membership import is_member
from services.entry import post_entry, refresh_entry
from services.mini import refresh_live
from services.referral import referral_link, credit_referral
from utils.fonts import small_caps
from utils.ui import force_sub, skip_caption, referral_join


async def route_deep_link(app, m, payload):
    if payload.startswith("participate_"):
        return await main_join(app, m, payload.split("_", 1)[1])
    if payload.startswith("minigiv_"):
        return await mini_join(app, m, payload.split("_", 1)[1])
    if payload.startswith("ref_"):
        return await referral_start(app, m, payload[len("ref_"):])


async def main_join(app, m, gid):
    g = await giveaways.find_one({"_id": gid, "type": "main"})
    if not g: return await m.reply_text(small_caps("this giveaway doesn't exist."))
    if g["status"] != "active": return await m.reply_text(small_caps("this giveaway has already ended."))
    if await participants.find_one({"giveaway_id": gid, "user_id": m.from_user.id}):
        return await m.reply_text(small_caps("you're already in this giveaway."))
    if m.from_user.id in g.get("banned_participants", []): return await m.reply_text(small_caps("you are banned from this giveaway."))
    if not await is_member(app, g["channel_id"], m.from_user.id):
        username = g.get("channel_username")
        url = f"https://t.me/{username}" if username else f"https://t.me/c/{str(g['channel_id']).replace('-100','')}"
        return await m.reply_text(small_caps("join this channel to participate."), reply_markup=force_sub(url, gid))
    await users.update_one({"_id": m.from_user.id}, {"$set": {"entry_pending": gid}}, upsert=True)
    return await m.reply_text(small_caps("send a short caption for your entry, or tap skip."), reply_markup=skip_caption(gid))


async def _notify_hoster(app, g, text):
    try:
        await app.send_message(g["hoster_id"], text)
    except Exception:
        pass  # hoster may have blocked the bot — never let this break the join flow


async def referral_start(app, m, rest):
    """Handles /start ref_<gid>_<referrer_id> deep links. New user must join
    the giveaway's referral channel before the referral counts — mirrors the
    existing force_sub join-gate pattern used for giveaway entries."""
    try:
        gid, referrer_str = rest.split("_", 1)
        referrer_id = int(referrer_str)
    except ValueError:
        return
    g = await giveaways.find_one({"_id": gid, "status": "active"})
    if not g or not g.get("referral_channel_id"):
        return await m.reply_text(small_caps("this referral link is no longer active."))
    if m.from_user.id == referrer_id:
        return await m.reply_text(small_caps("you can't refer yourself."))
    if await referrals.find_one({"giveaway_id": gid, "referred_id": m.from_user.id}):
        return await m.reply_text(small_caps("you've already used a referral link for this giveaway."))
    if not await is_member(app, g["referral_channel_id"], m.from_user.id):
        username = g.get("referral_channel_username")
        url = f"https://t.me/{username}" if username else f"https://t.me/c/{str(g['referral_channel_id']).replace('-100','')}"
        return await m.reply_text(
            f"{small_caps('join this channel to make your referral count')}:\n{g.get('referral_channel_title','')}",
            reply_markup=referral_join(url, gid, referrer_id))
    ok = await credit_referral(app, gid, referrer_id, m.from_user.id)
    await m.reply_text(small_caps("thanks! your referral has been counted.") if ok else small_caps("welcome!"))


async def submit_main(app, user, gid, caption):
    g = await giveaways.find_one({"_id": gid, "type": "main", "status": "active"})
    if not g: return None
    if user.id in g.get("banned_participants", []): return None
    existing = await participants.find_one({"giveaway_id": gid, "user_id": user.id})
    if existing: return existing
    p = {"giveaway_id": gid, "user_id": user.id, "name": user.first_name or "User", "username": user.username,
         "join_at": datetime.now(timezone.utc), "vote_count": 0, "manual_votes": 0, "referral_count": 0, "caption": caption}
    r = await participants.insert_one(p); p["_id"] = r.inserted_id
    await post_entry(app, g, p)
    await users.update_one({"_id": user.id}, {"$unset": {"entry_pending": ""}})
    count = await participants.count_documents({"giveaway_id": gid})
    await _notify_hoster(app, g, f"🎉 {small_caps('new entry')}\n#{gid} • {g.get('channel_title','')}\n{small_caps('entrant')}: {p['name']}\n{small_caps('total entries')}: {count}")
    if g.get("referral_channel_id"):
        try:
            await app.send_message(user.id, f"🔗 {small_caps('want more visibility? share your personal referral link')}:\n{referral_link(gid, user.id)}")
        except Exception:
            pass
    return p


async def mini_join(app, m, gid):
    g = await giveaways.find_one({"_id": gid, "type": "mini"})
    if not g: return await m.reply_text(small_caps("this giveaway doesn't exist."))
    if g["status"] != "active": return await m.reply_text(small_caps("this giveaway has already ended."))
    if m.from_user.id in g.get("banned_participants", []): return await m.reply_text(small_caps("you are banned from this giveaway."))
    existing = await participants.find_one({"giveaway_id": gid, "user_id": m.from_user.id})
    if existing:
        return await m.reply_text(f"{small_caps('you are already in this giveaway. your number is')} #{existing['number']}")
    if not await is_member(app, g["channel_id"], m.from_user.id):
        username = g.get("channel_username"); url = f"https://t.me/{username}" if username else ""
        return await m.reply_text(small_caps("join this channel to participate."), reply_markup=force_sub(url, gid))
    last = await participants.find_one({"giveaway_id": gid}, sort=[("number", -1)])
    number = (last.get("number", 0) + 1) if last else 1
    await participants.insert_one({"giveaway_id": gid, "user_id": m.from_user.id, "name": m.from_user.first_name or "User", "username": m.from_user.username,
                                    "join_at": datetime.now(timezone.utc), "number": number})
    await _notify_hoster(app, g, f"🎲 {small_caps('new entry')}\n#{gid} • {g.get('channel_title','')}\n{small_caps('entrant')}: {m.from_user.first_name or 'User'} — #{number}")
    mid = await refresh_live(app, g)
    if mid and not g.get("live_message_id"): await giveaways.update_one({"_id": gid}, {"$set": {"live_message_id": mid}})
    await m.reply_text(f"{small_caps('you are in! your number is')} #{number}")


def register(app):
    @app.on_callback_query(filters.regex(r"^recheck:"))
    async def recheck(app, q):
        gid = q.data.split(":")[1]
        g = await giveaways.find_one({"_id": gid, "status": "active"})
        if not g: return await q.answer(small_caps("this giveaway has ended."), show_alert=True)
        if not await is_member(app, g["channel_id"], q.from_user.id):
            return await q.answer(small_caps("please join this channel first."), show_alert=True)
        await users.update_one({"_id": q.from_user.id}, {"$set": {"entry_pending": gid}}, upsert=True)
        await q.message.reply_text(small_caps("send a short caption, or tap skip."), reply_markup=skip_caption(gid))
        await q.answer()

    @app.on_callback_query(filters.regex(r"^refcheck:"))
    async def refcheck(app, q):
        _, gid, referrer_str = q.data.split(":")
        referrer_id = int(referrer_str)
        g = await giveaways.find_one({"_id": gid, "status": "active"})
        if not g or not g.get("referral_channel_id"):
            return await q.answer(small_caps("this referral link is no longer active."), show_alert=True)
        if not await is_member(app, g["referral_channel_id"], q.from_user.id):
            return await q.answer(small_caps("please join the channel first."), show_alert=True)
        ok = await credit_referral(app, gid, referrer_id, q.from_user.id)
        await q.message.edit_text(small_caps("thanks! your referral has been counted.") if ok
                                   else small_caps("you've already been counted, or this link is no longer valid."))
        await q.answer()

    @app.on_callback_query(filters.regex(r"^caption_skip:"))
    async def skip(app, q):
        gid = q.data.split(":")[1]
        await submit_main(app, q.from_user, gid, "")
        await q.answer(small_caps("you're in! your entry is live."), show_alert=True)

    @app.on_message(filters.private & filters.text)
    async def caption_text(app, m):
        if m.text and m.text.startswith("/"):
            raise ContinuePropagation
        u = await users.find_one({"_id": m.from_user.id})
        gid = u.get("entry_pending") if u else None
        if not gid:
            raise ContinuePropagation
        if len(m.text) > 500: return await m.reply_text(small_caps("caption is too long. keep it under 500 characters."))
        await submit_main(app, m.from_user, gid, m.text)
        await m.reply_text(small_caps("you're in! your entry is live in the channel."))

    @app.on_callback_query(filters.regex(r"^vote:"))
    async def vote_cb(app, q: CallbackQuery):
        _, gid, pid = q.data.split(":"); pid = int(pid)
        g = await giveaways.find_one({"_id": gid, "type": "main"})
        if not g or g["status"] != "active": return await q.answer(small_caps("this giveaway has ended."), show_alert=True)
        if not await is_member(app, g["channel_id"], q.from_user.id):
            return await q.answer(small_caps("join this channel to vote."), show_alert=True)
        if q.from_user.id == pid: return await q.answer(small_caps("you can't vote for yourself."), show_alert=True)
        target = await participants.find_one({"giveaway_id": gid, "user_id": pid})
        if not target: return await q.answer(small_caps("this entry no longer exists."), show_alert=True)
        old = await voters.find_one({"giveaway_id": gid, "voter_id": q.from_user.id})
        if old:
            if old["participant_id"] == pid:
                await voters.delete_one({"_id": old["_id"]})
                target = await participants.find_one_and_update(
                    {"_id": target["_id"]}, {"$inc": {"vote_count": -1}}, return_document=ReturnDocument.AFTER)
                await refresh_entry(app, g, target)
                return await q.answer(small_caps("vote removed."), show_alert=True)
            return await q.answer(small_caps("you already voted for another participant. remove that vote first."), show_alert=True)
        await voters.insert_one({"giveaway_id": gid, "voter_id": q.from_user.id, "participant_id": pid, "created_at": datetime.now(timezone.utc)})
        target = await participants.find_one_and_update(
            {"_id": target["_id"]}, {"$inc": {"vote_count": 1}}, return_document=ReturnDocument.AFTER)
        await refresh_entry(app, g, target)
        await q.answer(small_caps("voted!"), show_alert=True)