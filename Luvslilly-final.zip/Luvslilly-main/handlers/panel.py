from pyrogram import filters, ContinuePropagation
from pyrogram.types import (ReplyKeyboardMarkup, ReplyKeyboardRemove,
                             InlineKeyboardMarkup, InlineKeyboardButton)
from database.db import users, admins, giveaways, access_sessions, get_role
from config import OWNER_ID, MAX_START_VIDEO_SECONDS
from utils.fonts import small_caps
from services.admin_actions import set_ban, set_admin_role, do_broadcast, do_broadcast_copy

OWNER_KB = ReplyKeyboardMarkup([
    ["📊 Stats", "📋 Active Giveaways"],
    ["🚫 Ban User", "✅ Unban User"],
    ["👑 Manage Admins", "📢 Broadcast"],
    ["🖼️ Start Media", "❌ Close Panel"],
], resize_keyboard=True)

SADMIN_KB = ReplyKeyboardMarkup([
    ["📊 Stats", "📋 Active Giveaways"],
    ["🔑 Access Giveaway", "❌ Close Panel"],
], resize_keyboard=True)

ADMIN_KB = ReplyKeyboardMarkup([
    ["📊 Stats", "📋 Active Giveaways"],
    ["❌ Close Panel"],
], resize_keyboard=True)

_MANAGE_ADMINS_KB = InlineKeyboardMarkup([
    [InlineKeyboardButton("➕ Add Admin", callback_data="pn:addadmin_id"),
     InlineKeyboardButton("➕ Add SAdmin", callback_data="pn:addsadmin_id")],
    [InlineKeyboardButton("➖ Remove Admin", callback_data="pn:removeadmin_id"),
     InlineKeyboardButton("➖ Remove SAdmin", callback_data="pn:removesadmin_id")],
])


async def _role(uid):
    return await get_role(uid, OWNER_ID)


def register(app):
    @app.on_message(filters.private & filters.command("owner"))
    async def owner_cmd(_, m):
        if m.from_user.id != OWNER_ID: return
        await m.reply_text(small_caps("owner panel — pick an action below."), reply_markup=OWNER_KB)

    @app.on_message(filters.private & filters.command("helppdf"))
    async def helppdf_cmd(_, m):
        if m.from_user.id != OWNER_ID: return
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("📄 " + small_caps("set normal user pdf"), callback_data="hpdf:user")],
            [InlineKeyboardButton("🔐 " + small_caps("set admin pdf"), callback_data="hpdf:admin")],
        ])
        await m.reply_text(small_caps("which guide do you want to update?"), reply_markup=kb)

    @app.on_callback_query(filters.regex(r"^hpdf:"))
    async def helppdf_cb(_, q):
        if q.from_user.id != OWNER_ID: return await q.answer()
        which = q.data.split(":", 1)[1]
        await users.update_one({"_id": q.from_user.id}, {"$set": {"panel_awaiting": f"guide_{which}_pdf"}}, upsert=True)
        await q.answer()
        await q.message.reply_text(small_caps("send the new pdf file now."))

    @app.on_message(filters.private & filters.document)
    async def receive_guide_pdf(_, m):
        u = await users.find_one({"_id": m.from_user.id})
        awaiting = u.get("panel_awaiting") if u else None
        if awaiting not in ("guide_user_pdf", "guide_admin_pdf"):
            return
        is_pdf = m.document.mime_type == "application/pdf" or (m.document.file_name or "").lower().endswith(".pdf")
        if not is_pdf:
            return await m.reply_text(small_caps("that's not a pdf. send a pdf file."))
        from database.db import settings
        await settings.update_one({"_id": awaiting}, {"$set": {"file_id": m.document.file_id}}, upsert=True)
        await users.update_one({"_id": m.from_user.id}, {"$unset": {"panel_awaiting": ""}})
        await m.reply_text(small_caps("guide updated. it'll be used from now on in /help."))

    @app.on_message(filters.private & filters.command("sadmin"))
    async def sadmin_cmd(_, m):
        if await _role(m.from_user.id) not in ("owner", "sadmin"): return
        await m.reply_text(small_caps("super admin panel — pick an action below."), reply_markup=SADMIN_KB)

    @app.on_message(filters.private & filters.command("admin"))
    async def admin_cmd(_, m):
        if await _role(m.from_user.id) not in ("owner", "sadmin", "admin"): return
        await m.reply_text(small_caps("admin panel — pick an action below."), reply_markup=ADMIN_KB)

    # --- reply-keyboard button presses (exact-text matches) ---

    @app.on_message(filters.private & filters.regex("^❌ Close Panel$"))
    async def close_panel(_, m):
        if await _role(m.from_user.id) not in ("owner", "sadmin", "admin"): raise ContinuePropagation
        await m.reply_text(small_caps("panel closed."), reply_markup=ReplyKeyboardRemove())

    @app.on_message(filters.private & filters.regex("^📊 Stats$"))
    async def btn_stats(_, m):
        if await _role(m.from_user.id) not in ("owner", "sadmin", "admin"): raise ContinuePropagation
        await m.reply_text(
            f"{small_caps('stats')}\n\n"
            f"{small_caps('users')}: {await users.count_documents({})}\n"
            f"{small_caps('active main')}: {await giveaways.count_documents({'type':'main','status':'active'})}\n"
            f"{small_caps('active mini')}: {await giveaways.count_documents({'type':'mini','status':'active'})}"
        )

    @app.on_message(filters.private & filters.regex("^📋 Active Giveaways$"))
    async def btn_active(_, m):
        if await _role(m.from_user.id) not in ("owner", "sadmin", "admin"): raise ContinuePropagation
        docs = await giveaways.find({"status": "active"}).to_list(length=200)
        text = small_caps("active giveaways") + "\n\n"
        text += "\n".join(f"#{g['_id']} • {g['type']} • {g.get('channel_title','')} • {g['hoster_id']}" for g in docs) or small_caps("none")
        await m.reply_text(text)

    @app.on_message(filters.private & filters.regex("^🚫 Ban User$"))
    async def btn_ban(_, m):
        if await _role(m.from_user.id) not in ("owner", "sadmin"): raise ContinuePropagation
        await users.update_one({"_id": m.from_user.id}, {"$set": {"panel_awaiting": "ban_id"}}, upsert=True)
        await m.reply_text(small_caps("send the user id to ban."))

    @app.on_message(filters.private & filters.regex("^✅ Unban User$"))
    async def btn_unban(_, m):
        if await _role(m.from_user.id) not in ("owner", "sadmin"): raise ContinuePropagation
        await users.update_one({"_id": m.from_user.id}, {"$set": {"panel_awaiting": "unban_id"}}, upsert=True)
        await m.reply_text(small_caps("send the user id to unban."))

    @app.on_message(filters.private & filters.regex("^🔑 Access Giveaway$"))
    async def btn_access(_, m):
        if await _role(m.from_user.id) not in ("owner", "sadmin"): raise ContinuePropagation
        await users.update_one({"_id": m.from_user.id}, {"$set": {"panel_awaiting": "access_gid"}}, upsert=True)
        await m.reply_text(small_caps("send the giveaway id. use /current or the active-giveaways button to see ids."))

    @app.on_message(filters.private & filters.regex("^👑 Manage Admins$"))
    async def btn_manage_admins(_, m):
        if m.from_user.id != OWNER_ID: raise ContinuePropagation
        await m.reply_text(small_caps("what would you like to do?"), reply_markup=_MANAGE_ADMINS_KB)

    @app.on_message(filters.private & filters.regex("^📢 Broadcast$"))
    async def btn_broadcast(_, m):
        if await _role(m.from_user.id) not in ("owner", "sadmin"): raise ContinuePropagation
        await users.update_one({"_id": m.from_user.id}, {"$set": {"panel_awaiting": "broadcast_msg"}}, upsert=True)
        await m.reply_text(small_caps("send the message to broadcast to all users."))

    @app.on_message(filters.private & filters.regex("^🖼️ Start Media$"))
    async def btn_startmedia(_, m):
        if m.from_user.id != OWNER_ID: raise ContinuePropagation
        await users.update_one({"_id": m.from_user.id}, {"$set": {"awaiting_startmedia": True}}, upsert=True)
        await m.reply_text(small_caps(f"send the photo or a short video (under {MAX_START_VIDEO_SECONDS}s) now."))

    # --- inline "Manage Admins" sub-menu ---

    @app.on_callback_query(filters.regex(r"^pn:"))
    async def manage_admins_cb(_, q):
        if q.from_user.id != OWNER_ID: return await q.answer()
        action = q.data.split(":", 1)[1]
        await users.update_one({"_id": q.from_user.id}, {"$set": {"panel_awaiting": action}}, upsert=True)
        await q.answer()
        await q.message.reply_text(small_caps("send the user id."))

    # --- non-text broadcast content (stickers, photos, GIFs, videos, docs) ---
    # panel_text below only fires on filters.text, so broadcast content that
    # isn't plain text needs its own catch here.
    @app.on_message(filters.private & (filters.sticker | filters.animation | filters.photo | filters.video | filters.document) & ~filters.text)
    async def panel_media_broadcast(app, m):
        u = await users.find_one({"_id": m.from_user.id})
        awaiting = u.get("panel_awaiting") if u else None
        if awaiting != "broadcast_msg":
            raise ContinuePropagation
        await users.update_one({"_id": m.from_user.id}, {"$unset": {"panel_awaiting": ""}})
        status = await m.reply_text(small_caps("broadcasting..."))
        ok, fail = await do_broadcast_copy(app, m)
        await status.edit_text(f"{small_caps('broadcast complete')}\n✓ {ok}  ✕ {fail}")

    # --- generic text catch for panel_awaiting states (must be registered
    # before setup.py / giveaway.py's generic text catch-alls; see main.py
    # module order) ---

    @app.on_message(filters.private & filters.text)
    async def panel_text(app, m):
        if m.text and m.text.startswith("/"):
            raise ContinuePropagation
        u = await users.find_one({"_id": m.from_user.id})
        awaiting = u.get("panel_awaiting") if u else None
        if not awaiting:
            raise ContinuePropagation
        await users.update_one({"_id": m.from_user.id}, {"$unset": {"panel_awaiting": ""}})
        try:
            if awaiting in ("ban_id", "unban_id"):
                uid = int(m.text.strip())
                await set_ban(uid, awaiting == "ban_id")
                return await m.reply_text(small_caps("done."))
            if awaiting == "broadcast_msg":
                status = await m.reply_text(small_caps("broadcasting..."))
                ok, fail = await do_broadcast_copy(app, m)
                return await status.edit_text(f"{small_caps('broadcast complete')}\n✓ {ok}  ✕ {fail}")
            if awaiting in ("addadmin_id", "addsadmin_id", "removeadmin_id", "removesadmin_id"):
                uid = int(m.text.strip())
                if awaiting == "addadmin_id": await set_admin_role(app, uid, "admin")
                elif awaiting == "addsadmin_id": await set_admin_role(app, uid, "sadmin")
                else: await set_admin_role(app, uid, None)
                return await m.reply_text(small_caps("done."))
            if awaiting == "access_gid":
                gid = m.text.strip()
                g = await giveaways.find_one({"_id": gid})
                if not g:
                    return await m.reply_text(small_caps("giveaway not found."))
                await access_sessions.update_one({"_id": m.from_user.id}, {"$set": {"giveaway_id": gid, "hoster_id": g["hoster_id"]}}, upsert=True)
                kb = InlineKeyboardMarkup([[InlineKeyboardButton("👥 " + small_caps("participants"), callback_data=f"accessp:{gid}")],
                                            [InlineKeyboardButton("🚪 " + small_caps("exit"), callback_data="access_exit")]])
                return await m.reply_text(f"{small_caps('access mode active')}\n\nID: {gid}\n{small_caps('hoster')}: {g['hoster_id']}", reply_markup=kb)
        except ValueError:
            await m.reply_text(small_caps("that doesn't look like a valid user id. try again."))