from pyrogram import filters, ContinuePropagation
from database.db import users, admins, giveaways, settings, get_role
from config import OWNER_ID, MAX_START_VIDEO_SECONDS
from utils.fonts import small_caps
from services.admin_actions import set_ban, set_admin_role, do_broadcast


def register(app):
    @app.on_message(filters.private & filters.command(["addadmin", "removeadmin", "saddadmin", "remsadmin"]))
    async def admins_cmd(app, m):
        if m.from_user.id != OWNER_ID: return
        if len(m.command) < 2: return await m.reply_text(small_caps("usage: /" + m.command[0].lower() + " <user_id>."))
        uid = int(m.command[1]); cmd = m.command[0].lower()
        if cmd in ("addadmin", "saddadmin"):
            await set_admin_role(app, uid, "sadmin" if cmd == "saddadmin" else "admin")
        else:
            await set_admin_role(app, uid, None)
        await m.reply_text(small_caps("done."))

    @app.on_message(filters.private & filters.command(["stats", "current"]))
    async def overview(_, m):
        r = await get_role(m.from_user.id, OWNER_ID)
        if r not in ("owner", "admin", "sadmin"): return
        if m.command[0].lower() == "stats":
            await m.reply_text(
                f"{small_caps('stats')}\n\n"
                f"{small_caps('users')}: {await users.count_documents({})}\n"
                f"{small_caps('active main')}: {await giveaways.count_documents({'type':'main','status':'active'})}\n"
                f"{small_caps('active mini')}: {await giveaways.count_documents({'type':'mini','status':'active'})}"
            )
        else:
            docs = await giveaways.find({"status": "active"}).to_list(length=200)
            text = small_caps("active giveaways") + "\n\n"
            text += "\n".join(f"#{g['_id']} • {g['type']} • {g.get('channel_title','')} • {g['hoster_id']}" for g in docs) or small_caps("none")
            await m.reply_text(text)

    @app.on_message(filters.private & filters.command(["ban", "unban"]))
    async def ban(_, m):
        r = await get_role(m.from_user.id, OWNER_ID)
        if r not in ("owner", "sadmin"): return
        if len(m.command) < 2: return await m.reply_text(small_caps("usage: /" + m.command[0].lower() + " <user_id>."))
        uid = int(m.command[1])
        await set_ban(uid, m.command[0].lower() == "ban")
        await m.reply_text(small_caps("done."))

    @app.on_message(filters.private & filters.command("broadcast"))
    async def broadcast(app, m):
        r = await get_role(m.from_user.id, OWNER_ID)
        if r not in ("owner", "sadmin"): return
        if len(m.command) < 2: return await m.reply_text(small_caps("usage: /broadcast <message>."))
        msg = m.text.split(None, 1)[1]
        status = await m.reply_text(small_caps("broadcasting..."))
        ok, fail = await do_broadcast(app, msg)
        await status.edit_text(f"{small_caps('broadcast complete')}\n✓ {ok}  ✕ {fail}")

    @app.on_message(filters.private & filters.command(["startpic", "startmedia"]))
    async def startmedia(_, m):
        if m.from_user.id != OWNER_ID: return
        await users.update_one({"_id": m.from_user.id}, {"$set": {"awaiting_startmedia": True}}, upsert=True)
        await m.reply_text(small_caps(f"send the photo or a short video (under {MAX_START_VIDEO_SECONDS}s) now."))

    @app.on_message(filters.private & filters.command("entrypic"))
    async def entrypic(_, m):
        # Owner-only: sets the single fixed photo used for EVERY participant's
        # entry post, replacing the old per-user profile-photo fetch.
        if m.from_user.id != OWNER_ID: return
        await users.update_one({"_id": m.from_user.id}, {"$set": {"awaiting_entrypic": True}}, upsert=True)
        await m.reply_text(small_caps("send the photo to use for every entry post now."))

    @app.on_message(filters.private & (filters.photo | filters.video))
    async def receive_startmedia(_, m):
        u = await users.find_one({"_id": m.from_user.id})
        if not u:
            raise ContinuePropagation
        if u.get("awaiting_entrypic") and m.photo:
            await settings.update_one({"_id": "entrypic"}, {"$set": {"file_id": m.photo.file_id}}, upsert=True)
            await users.update_one({"_id": m.from_user.id}, {"$unset": {"awaiting_entrypic": ""}})
            return await m.reply_text(small_caps("entry photo updated. every new/refreshed entry will now use it."))
        if not u.get("awaiting_startmedia"):
            raise ContinuePropagation  # let other handlers (e.g. broadcast photo) see this
        if m.video and m.video.duration and m.video.duration > MAX_START_VIDEO_SECONDS:
            return await m.reply_text(small_caps(f"video is too long. keep it under {MAX_START_VIDEO_SECONDS} seconds."))
        if m.photo:
            await settings.update_one({"_id": "startmedia"}, {"$set": {"type": "photo", "file_id": m.photo.file_id}}, upsert=True)
        else:
            await settings.update_one({"_id": "startmedia"}, {"$set": {"type": "video", "file_id": m.video.file_id}}, upsert=True)
        await users.update_one({"_id": m.from_user.id}, {"$unset": {"awaiting_startmedia": ""}})
        await m.reply_text(small_caps("start banner updated."))
      
