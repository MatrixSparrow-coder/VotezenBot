import logging
from pyrogram import filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from database.db import track_user, is_banned, settings, get_role
from config import BOT_USERNAME, OWNER_ID
from utils.fonts import small_caps, heavy_channel
from handlers.giveaway import route_deep_link


START_TEXT = f"""{heavy_channel('VOTEZENBOT')}
━━━━━━━━━━━━━━━━

{small_caps('giveaways, decided by the crowd.')}

🎉 {small_caps('run a giveaway in your channel — people join, people vote, the best entry wins.')}
🎲 {small_caps('or run a quick random-draw mini giveaway — no voting, just numbers and luck.')}

👇 {small_caps('tap below to get started.')}"""


HELP_INTRO = f"""{heavy_channel('HOW IT WORKS')}
━━━━━━━━━━━━━━━━

📌 {small_caps('hosting a giveaway')}
1. /addch — {small_caps('save a channel (i must be admin there)')}
2. /host {small_caps('or')} /minigiv — {small_caps('pick that channel, set an optional start/end time, and confirm')}
3. {small_caps("once it's created, a keyboard pops up below your chat")}:
   🎉 {small_caps('host giveaway')} • 🎲 {small_caps('mini giveaway')} • 🔁 {small_caps('referral system')} • ❌ {small_caps('close panel')}
4. {small_caps("share the link the bot gives you — that's how people join")}"""


# Only shown to someone who's actually hosting (or staff) — see send_help().
# A plain participant should never see these commands exist, same rule as
# the "/" command menu itself (services/commands.py).
HOSTER_LIVE_BLOCK = f"""🎯 {small_caps('while a giveaway is live')}
• {small_caps('tap')} 📡 {small_caps('monitor giveaways')} {small_caps('on the keyboard, then pick a giveaway from the list')}
• {small_caps('a new keyboard appears for that giveaway')}: ➕ {small_caps('increase votes')} • 👥 {small_caps('participants')} • 🏁 {small_caps('end')} • 🔥 {small_caps('cancel')}
• /mystats — {small_caps('same list, if you prefer typing')}
• /banp / /unbanp — {small_caps('ban or unban a participant')}"""


REFERRAL_BLOCK = f"""🔁 {small_caps('referral system')} ({small_caps('optional')})
• {small_caps('tap')} 🔁 {small_caps('referral system')} {small_caps('on the keyboard, pick which giveaway gets the leaderboard')}
• {small_caps("give me a link to any channel where i'm admin — that channel is used to verify joins only")}
• {small_caps('every participant then gets their own personal referral link to share — the leaderboard posts on the giveaway channel itself')}"""


PARTICIPANT_BLOCK = f"""🙋 {small_caps('for participants')}
• {small_caps('tap a giveaway link, join the required channel(s), and follow the prompts')}
• /leaderboard — {small_caps('check your rank or entry number')}"""


async def send_help(uid, send_text, send_doc):
    """send_text(text) and send_doc(path_or_file_id, caption) come from the
    caller's own context (m.reply_text/m.reply_document, or the same via
    q.message). Which PDF gets attached depends on role: staff get the
    admin/owner manual, everyone else gets the normal-user guide. Whatever
    the owner has most recently set via /helppdf takes priority; otherwise
    falls back to the bundled default file."""

    role = await get_role(uid, OWNER_ID)
    is_staff = role in ("owner", "sadmin", "admin")
    is_hoster = is_staff

    if not is_hoster:
        from database.db import giveaways
        is_hoster = bool(
            await giveaways.find_one(
                {
                    "hoster_id": uid,
                    "status": "active"
                }
            )
        )

    blocks = [HELP_INTRO]

    if is_hoster:
        blocks.append(HOSTER_LIVE_BLOCK)

    blocks += [REFERRAL_BLOCK, PARTICIPANT_BLOCK]

    await send_text("\n\n".join(blocks))

    if is_staff:
        doc = await settings.find_one({"_id": "guide_admin_pdf"})
        target = (
            doc["file_id"]
            if doc and doc.get("file_id")
            else "static/guide_admin.pdf"
        )
        caption = small_caps("staff operations manual.")
    else:
        doc = await settings.find_one({"_id": "guide_user_pdf"})
        target = (
            doc["file_id"]
            if doc and doc.get("file_id")
            else "static/guide_user.pdf"
        )
        caption = small_caps(
            "full guide — how to host, manage, and grow a giveaway."
        )

    try:
        await send_doc(target, caption)
    except Exception:
        # Bundled PDF missing/unreadable, or a stale file_id from a since-
        # deleted message — never let a broken guide attachment break the
        # rest of /help. The text above has already been sent either way.
        logging.getLogger(__name__).warning(
            "send_help: failed to send guide document (target=%r)", target
        )


def main_menu_kb():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "🎉 " + small_caps("host giveaway"),
                callback_data="menu:host"
            ),
            InlineKeyboardButton(
                "🎲 " + small_caps("mini giveaway"),
                callback_data="menu:mini"
            )
        ],
        [
            InlineKeyboardButton(
                "📋 " + small_caps("my channels"),
                callback_data="menu:channels"
            ),
            InlineKeyboardButton(
                "📊 " + small_caps("my giveaways"),
                callback_data="menu:mystats"
            )
        ],
        [
            InlineKeyboardButton(
                "ℹ️ " + small_caps("how it works"),
                callback_data="menu:help"
            )
        ],
    ])


def register(app):

    @app.on_message(filters.private & filters.command("start"))
    async def start(app, m):
        await track_user(m.from_user)

        if await is_banned(m.from_user.id):
            return await m.reply_text(
                small_caps("you are banned from using this bot.")
            )

        payload = m.command[1] if len(m.command) > 1 else ""

        if (
            payload.startswith("participate_")
            or payload.startswith("minigiv_")
            or payload.startswith("ref_")
        ):
            return await route_deep_link(app, m, payload)

        greeting = (
            f"👋 {small_caps('hey')} "
            f"{m.from_user.mention}!\n\n"
        )

        text = greeting + START_TEXT
        kb = main_menu_kb()

        media = await settings.find_one({"_id": "startmedia"})

        if media and media.get("file_id"):

            if media.get("type") == "video":
                return await m.reply_video(
                    media["file_id"],
                    caption=text,
                    reply_markup=kb
                )

            return await m.reply_photo(
                media["file_id"],
                caption=text,
                reply_markup=kb
            )

        await m.reply_text(
            text,
            reply_markup=kb
        )


    @app.on_callback_query(filters.regex(r"^menu:"))
    async def menu_cb(app, q):
        await q.answer()

        action = q.data.split(":", 1)[1]

        if action == "help":
            return await send_help(
                q.from_user.id,
                q.message.reply_text,
                q.message.reply_document
            )

        if action in ("host", "mini"):
            from handlers.setup import begin_flow

            return await begin_flow(
                app,
                q.message,
                q.from_user,
                "main" if action == "host" else "mini"
            )

        if action == "channels":
            from handlers.channels import list_channels_text

            return await q.message.reply_text(
                await list_channels_text(q.from_user.id)
            )

        if action == "mystats":
            from handlers.hoster import mystats_text
            from pyrogram.types import (
                InlineKeyboardMarkup,
                InlineKeyboardButton
            )

            text, docs = await mystats_text(q.from_user.id)

            if not docs:
                return await q.message.reply_text(text)

            kb = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        f"#{g['_id']} • {g['type']} • {g['status']}",
                        callback_data=f"gmanage:{g['_id']}"
                    )
                ]
                for g in docs
            ])

            return await q.message.reply_text(
                text,
                reply_markup=kb
            )


    @app.on_callback_query(filters.regex("^help$"))
    async def help_cb(_, q):
        await send_help(
            q.from_user.id,
            q.message.reply_text,
            q.message.reply_document
        )


    @app.on_message(filters.private & filters.command("help"))
    async def help_cmd(_, m):
        await send_help(
            m.from_user.id,
            m.reply_text,
            m.reply_document
        )