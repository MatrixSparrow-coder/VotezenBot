from pyrogram import filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from database.db import giveaways, participants, access_sessions, get_role
from config import OWNER_ID
from utils.fonts import small_caps
from utils.text import escape_md

def register(app):
    @app.on_message(filters.private & filters.command("access"))
    async def access(_,m):
        r=await get_role(m.from_user.id,OWNER_ID)
        if r not in ("owner","sadmin"):return
        if len(m.command)<2:return await m.reply_text(small_caps("usage: /access <giveaway_id>. use /current to see ids."))
        gid=m.command[1]; g=await giveaways.find_one({"_id":gid})
        if not g:return await m.reply_text(small_caps("giveaway not found."))
        await access_sessions.update_one({"_id":m.from_user.id},{"$set":{"giveaway_id":gid,"hoster_id":g["hoster_id"]}},upsert=True)
        kb=InlineKeyboardMarkup([[InlineKeyboardButton("👥 "+small_caps("participants"),callback_data=f"accessp:{gid}")],
                                 [InlineKeyboardButton("🚪 "+small_caps("exit"),callback_data="access_exit")]])
        await m.reply_text(f"{small_caps('access mode active')}\n\nID: {gid}\n{small_caps('hoster')}: {g['hoster_id']}",reply_markup=kb)
    @app.on_callback_query(filters.regex(r"^accessp:"))
    async def accessp(_,q):
        r=await get_role(q.from_user.id,OWNER_ID)
        if r not in ("owner","sadmin"):return
        gid=q.data.split(":")[1]
        ps=await participants.find({"giveaway_id":gid}).sort("join_at",1).to_list(length=200)
        if not ps:return await q.answer(small_caps("no participants."),show_alert=True)
        lines=[]
        for i,p in enumerate(ps,1):
            uname=f"@{p['username']}" if p.get('username') else small_caps("no username")
            lines.append(f"{i}. {escape_md(p.get('name','User'))} ({uname}) — ID {p['user_id']} • {p.get('vote_count',0)} {small_caps('votes')}")
        text=small_caps("participants")+"\n\n"+"\n".join(lines)
        await q.message.edit_text(text)
    @app.on_callback_query(filters.regex("^access_exit$"))
    async def exit_cb(_,q):
        await access_sessions.delete_one({"_id":q.from_user.id})
        await q.message.edit_text(small_caps("access mode closed."))
    @app.on_message(filters.private & filters.command("exit"))
    async def exit_cmd(_,m):
        await access_sessions.delete_one({"_id":m.from_user.id})
        await m.reply_text(small_caps("access mode closed."))
    _register_export(app)


def _register_export(app):
    from services.lifecycle import export_to_user
    @app.on_callback_query(filters.regex(r"^export:"))
    async def export_cb(app,q):
        gid=q.data.split(":",1)[1]
        g=await giveaways.find_one({"_id":gid})
        if not g:return await q.answer(small_caps("giveaway not found."),show_alert=True)
        if q.from_user.id not in (g["hoster_id"], OWNER_ID):
            r=await get_role(q.from_user.id,OWNER_ID)
            if r!="sadmin":return await q.answer()
        await q.answer(small_caps("preparing your file..."))
        await export_to_user(app,gid,q.from_user.id)