from pyrogram import filters, ContinuePropagation
from pyrogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove
from database.db import giveaways, participants, voters, get_role, access_sessions, users, channels as saved_channels
from config import OWNER_ID
from utils.fonts import small_caps
from utils.text import escape_md
from utils.ui import yes_no
from services.lifecycle import end_giveaway, cancel_giveaway
from services.membership import is_channel_admin
from services.referral import refresh_referral_board

HOSTER_KB = ReplyKeyboardMarkup([
    ["📡 Monitor Giveaways", "🏆 Leaderboard"],
    ["🔁 Referral System"],
    ["❌ Close Menu"],
], resize_keyboard=True)

MANAGE_KB_ACTIVE = ReplyKeyboardMarkup([
    ["➕ Increase Votes", "👥 Participants"],
    ["🏁 End Giveaway", "🔥 Cancel Giveaway"],
    ["🔙 Back to Menu"],
], resize_keyboard=True)

MANAGE_KB_ENDED = ReplyKeyboardMarkup([
    ["📄 Export Data"],
    ["🔙 Back to Menu"],
], resize_keyboard=True)


async def has_access_to(user_id, gid):
    sess = await access_sessions.find_one({"_id": user_id})
    return bool(sess and sess.get("giveaway_id") == gid)


async def _get_managed(uid):
    u = await users.find_one({"_id": uid})
    gid = u.get("managing_gid") if u else None
    if not gid:
        return None, None
    g = await giveaways.find_one({"_id": gid, "hoster_id": uid})
    return gid, g


async def mystats_text(uid):
    docs = await giveaways.find({"hoster_id": uid, "cleaned": {"$ne": True}}).sort("created_at", -1).limit(15).to_list(length=15)
    if not docs:
        return small_caps("no hosted giveaways yet."), []
    text = small_caps("your giveaways") + "\n" + small_caps("tap one to manage it.")
    return text, docs


_INCR_PAGE_SIZE = 8
_INCR_AMOUNTS = (1, 5, 10)


def _incr_list_kb(gid, page, ps):
    start = page * _INCR_PAGE_SIZE
    page_ps = ps[start:start + _INCR_PAGE_SIZE]
    rows = [[InlineKeyboardButton(
        f"{escape_md(p.get('name','User'))} — {p.get('vote_count',0)} " + small_caps("votes"),
        callback_data=f"incrpick:{gid}:{p['user_id']}"
    )] for p in page_ps]
    nav = []
    if page > 0: nav.append(InlineKeyboardButton("◀️", callback_data=f"incrlist:{gid}:{page-1}"))
    if start + _INCR_PAGE_SIZE < len(ps): nav.append(InlineKeyboardButton("▶️", callback_data=f"incrlist:{gid}:{page+1}"))
    if nav: rows.append(nav)
    return InlineKeyboardMarkup(rows)


def _incr_amount_kb(gid, uid):
    row = [InlineKeyboardButton(f"+{a}", callback_data=f"incrdo:{gid}:{uid}:{a}") for a in _INCR_AMOUNTS]
    return InlineKeyboardMarkup([row, [InlineKeyboardButton("🔙 " + small_caps("back"), callback_data=f"incrlist:{gid}:0")]])
def register(app):
    @app.on_message(filters.private & filters.command("end"))
    async def end(_, m):
        if len(m.command) < 2: return await m.reply_text(small_caps("usage: /end <giveaway_id>."))
        gid = m.command[1]
        g = await giveaways.find_one({"_id": gid, "status": "active"})
        if not g: return await m.reply_text(small_caps("active giveaway not found."))
        if g["hoster_id"] != m.from_user.id and not await has_access_to(m.from_user.id, gid): return
        await m.reply_text(f"{small_caps('end giveaway')} #{gid}\n\n{small_caps('are you sure?')}", reply_markup=yes_no(f"end:{gid}"))

    @app.on_message(filters.private & filters.command("cancel"))
    async def cancel(_, m):
        if len(m.command) < 2: return await m.reply_text(small_caps("usage: /cancel <giveaway_id>."))
        gid = m.command[1]
        g = await giveaways.find_one({"_id": gid, "status": "active"})
        if not g: return await m.reply_text(small_caps("active giveaway not found."))
        if g["hoster_id"] != m.from_user.id and not await has_access_to(m.from_user.id, gid): return
        await m.reply_text(f"{small_caps('cancel giveaway')} 🔥 #{gid}\n\n{small_caps('this will remove participant entry posts. are you sure?')}",
                            reply_markup=yes_no(f"cancel:{gid}"))

    @app.on_callback_query(filters.regex(r"^(end|cancel):"))
    async def lifecycle_cb(app, q: CallbackQuery):
        action, gid, answer = q.data.split(":")
        if answer == "no":
            return await q.message.edit_text(small_caps("action cancelled."))
        g = await giveaways.find_one({"_id": gid, "status": "active"})
        if not g:
            return await q.message.edit_text(small_caps("this giveaway is no longer active."))
        if action == "end": ok = await end_giveaway(app, gid, q.from_user.id)
        else: ok = await cancel_giveaway(app, gid)
        await q.message.edit_text(small_caps("done.") if ok else small_caps("couldn't complete that action."))
        if ok:
            await users.update_one({"_id": q.from_user.id}, {"$unset": {"managing_gid": ""}})
            await app.send_message(q.from_user.id, small_caps("back to hoster menu."), reply_markup=HOSTER_KB)

    @app.on_message(filters.private & filters.command("incr"))
    async def incr(app, m):
        if len(m.command) < 4: return await m.reply_text(small_caps("usage: /incr <giveaway_id> <user_id> <amount>."))
        gid, uid, amount = m.command[1], int(m.command[2]), int(m.command[3])
        if amount <= 0: return await m.reply_text(small_caps("/incr only increases votes. amount must be positive."))
        g = await giveaways.find_one({"_id": gid, "status": "active", "type": "main"})
        if not g: return await m.reply_text(small_caps("active main giveaway not found."))
        sess = await access_sessions.find_one({"_id": m.from_user.id})
        has_access = bool(sess and sess.get("giveaway_id") == gid)
        if g["hoster_id"] != m.from_user.id and not has_access: return
        from pymongo import ReturnDocument
        p = await participants.find_one_and_update(
            {"giveaway_id": g["_id"], "user_id": uid},
            {"$inc": {"vote_count": amount, "manual_votes": amount}},
            return_document=ReturnDocument.AFTER,
        )
        if not p: return await m.reply_text(small_caps("participant not found."))
        from services.entry import refresh_entry
        await refresh_entry(app, g, p)
        await m.reply_text(small_caps("votes increased."))

    @app.on_message(filters.private & filters.command(["banp", "unbanp"]))
    async def banp(app, m):
        if len(m.command) < 3: return await m.reply_text(small_caps("usage: /" + m.command[0].lower() + " <giveaway_id> <user_id>."))
        gid, uid = m.command[1], int(m.command[2])
        sess = await access_sessions.find_one({"_id": m.from_user.id})
        g = await giveaways.find_one({"_id": gid})
        has_access = bool(sess and sess.get("giveaway_id") == gid)
        if not g or (g["hoster_id"] != m.from_user.id and not has_access): return
        if m.command[0].lower() == "banp":
            p = await participants.find_one({"giveaway_id": gid, "user_id": uid})
            if p and p.get("message_id"):
                try: await app.delete_messages(g["channel_id"], p["message_id"])
                except Exception: pass
            await participants.delete_one({"giveaway_id": gid, "user_id": uid})
            await voters.delete_many({"giveaway_id": gid, "voter_id": uid})
            await voters.delete_many({"giveaway_id": gid, "participant_id": uid})
            await giveaways.update_one({"_id": gid}, {"$addToSet": {"banned_participants": uid}})
        else:
            await giveaways.update_one({"_id": gid}, {"$pull": {"banned_participants": uid}})
        await m.reply_text(small_caps("done."))

    @app.on_message(filters.private & filters.command("mystats"))
    async def mystats(_, m):
        text, docs = await mystats_text(m.from_user.id)
        if not docs: return await m.reply_text(text)
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(
            f"#{g['_id']} • {g['type']} • {g['status']}", callback_data=f"gmanage:{g['_id']}"
        )] for g in docs])
        await m.reply_text(text, reply_markup=kb)

    @app.on_callback_query(filters.regex(r"^gmanage:"))
    async def gmanage_cb(app, q):
        gid = q.data.split(":", 1)[1]
        g = await giveaways.find_one({"_id": gid, "hoster_id": q.from_user.id})
        if not g: return await q.answer(small_caps("giveaway not found."), show_alert=True)
        count = await participants.count_documents({"giveaway_id": gid})
        text = f"{small_caps('giveaway')} #{gid}\n\n{small_caps('type')}: {g['type']}\n{small_caps('channel')}: {g.get('channel_title','')}\n{small_caps('status')}: {g['status']}\n{small_caps('entries')}: {count}"
        await q.message.edit_text(text)
        await users.update_one({"_id": q.from_user.id}, {"$set": {"managing_gid": gid}}, upsert=True)
        kb = MANAGE_KB_ACTIVE if g["status"] == "active" else MANAGE_KB_ENDED
        await q.answer()
        await app.send_message(q.from_user.id, small_caps("what would you like to do?"), reply_markup=kb)

    @app.on_message(filters.private & filters.regex("^👥 Participants$"))
    async def mkb_participants(_, m):
        gid, g = await _get_managed(m.from_user.id)
        if not g: return await m.reply_text(small_caps("select a giveaway first via 📡 monitor giveaways."))
        ps = await participants.find({"giveaway_id": gid}).sort("join_at", 1).to_list(length=200)
        if not ps: return await m.reply_text(small_caps("no participants yet."))
        lines = []
        for i, p in enumerate(ps, 1):
            uname = f"@{p['username']}" if p.get('username') else small_caps("no username")
            lines.append(f"{i}. {escape_md(p.get('name','User'))} ({uname}) — ID {p['user_id']} • {p.get('vote_count',0)} {small_caps('votes')}")
        await m.reply_text(small_caps("participants") + "\n\n" + "\n".join(lines))

    @app.on_message(filters.private & filters.regex("^🏁 End Giveaway$"))
    async def mkb_end(_, m):
        gid, g = await _get_managed(m.from_user.id)
        if not g or g["status"] != "active":
            return await m.reply_text(small_caps("select an active giveaway first via 📡 monitor giveaways."))
        await m.reply_text(f"{small_caps('end giveaway')} #{gid}\n\n{small_caps('are you sure?')}", reply_markup=yes_no(f"end:{gid}"))

    @app.on_message(filters.private & filters.regex("^🔥 Cancel Giveaway$"))
    async def mkb_cancel(_, m):
        gid, g = await _get_managed(m.from_user.id)
        if not g or g["status"] != "active":
            return await m.reply_text(small_caps("select an active giveaway first via 📡 monitor giveaways."))
        await m.reply_text(
            f"{small_caps('cancel giveaway')} 🔥 #{gid}\n\n{small_caps('this will remove participant entry posts. are you sure?')}",
            reply_markup=yes_no(f"cancel:{gid}"))

    @app.on_message(filters.private & filters.regex("^📄 Export Data$"))
    async def mkb_export(app, m):
        gid, g = await _get_managed(m.from_user.id)
        if not g: return await m.reply_text(small_caps("select a giveaway first via 📡 monitor giveaways."))
        from services.lifecycle import export_to_user
        ok = await export_to_user(app, gid, m.from_user.id)
        if not ok: await m.reply_text(small_caps("nothing to export — data may already be cleaned up."))

    @app.on_message(filters.private & filters.regex("^🔙 Back to Menu$"))
    async def mkb_back(_, m):
        await users.update_one({"_id": m.from_user.id}, {"$unset": {"managing_gid": ""}})
        await m.reply_text(small_caps("back to hoster menu."), reply_markup=HOSTER_KB)

    @app.on_message(filters.private & filters.regex("^➕ Increase Votes$"))
    async def mkb_incr(_, m):
        gid, g = await _get_managed(m.from_user.id)
        if not g or g["status"] != "active" or g["type"] != "main":
            return await m.reply_text(small_caps("increase votes only works for an active main giveaway. select one via 📡 monitor giveaways."))
        ps = await participants.find({"giveaway_id": gid}).sort("vote_count", -1).to_list(length=200)
        if not ps: return await m.reply_text(small_caps("no participants yet."))
        await m.reply_text(small_caps("pick a participant to add votes to:"), reply_markup=_incr_list_kb(gid, 0, ps))

    @app.on_callback_query(filters.regex(r"^incrlist:"))
    async def incrlist_cb(_, q):
        _, gid, page = q.data.split(":")
        page = int(page)
        g = await giveaways.find_one({"_id": gid, "status": "active", "type": "main"})
        if not g or (g["hoster_id"] != q.from_user.id and not await has_access_to(q.from_user.id, gid)):
            return await q.answer(small_caps("giveaway not found."), show_alert=True)
        ps = await participants.find({"giveaway_id": gid}).sort("vote_count", -1).to_list(length=200)
        if not ps: return await q.answer(small_caps("no participants yet."), show_alert=True)
        await q.answer()
        await q.message.edit_text(small_caps("pick a participant to add votes to:"), reply_markup=_incr_list_kb(gid, page, ps))

    @app.on_callback_query(filters.regex(r"^incrpick:"))
    async def incrpick_cb(_, q):
        _, gid, uid = q.data.split(":")
        uid = int(uid)
        g = await giveaways.find_one({"_id": gid, "status": "active", "type": "main"})
        if not g or (g["hoster_id"] != q.from_user.id and not await has_access_to(q.from_user.id, gid)):
            return await q.answer(small_caps("giveaway not found."), show_alert=True)
        p = await participants.find_one({"giveaway_id": gid, "user_id": uid})
        if not p: return await q.answer(small_caps("participant not found."), show_alert=True)
        await q.answer()
        await q.message.edit_text(
            f"{escape_md(p.get('name','User'))} — {small_caps('currently')} {p.get('vote_count',0)} {small_caps('votes')}\n{small_caps('add how many?')}",
            reply_markup=_incr_amount_kb(gid, uid))

    @app.on_callback_query(filters.regex(r"^incrdo:"))
    async def incrdo_cb(app, q):
        _, gid, uid, amount = q.data.split(":")
        uid = int(uid); amount = int(amount)
        g = await giveaways.find_one({"_id": gid, "status": "active", "type": "main"})
        if not g or (g["hoster_id"] != q.from_user.id and not await has_access_to(q.from_user.id, gid)):
            return await q.answer(small_caps("giveaway not found."), show_alert=True)
        from pymongo import ReturnDocument
        p = await participants.find_one_and_update(
            {"giveaway_id": gid, "user_id": uid},
            {"$inc": {"vote_count": amount, "manual_votes": amount}},
            return_document=ReturnDocument.AFTER,
        )
        if not p: return await q.answer(small_caps("participant not found."), show_alert=True)
        from services.entry import refresh_entry
        await refresh_entry(app, g, p)
        await q.answer(f"+{amount} " + small_caps("votes added!"), show_alert=True)
        ps = await participants.find({"giveaway_id": gid}).sort("vote_count", -1).to_list(length=200)
        await q.message.edit_text(small_caps("pick a participant to add votes to:"), reply_markup=_incr_list_kb(gid, 0, ps))

    @app.on_message(filters.private & filters.regex("^📡 Monitor Giveaways$"))
    async def hoster_kb_mystats(_, m):
        text, docs = await mystats_text(m.from_user.id)
        if not docs: return await m.reply_text(text)
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(
            f"#{g['_id']} • {g['type']} • {g['status']}", callback_data=f"gmanage:{g['_id']}"
        )] for g in docs])
        await m.reply_text(text, reply_markup=kb)

    @app.on_message(filters.private & filters.regex("^❌ Close Menu$"))
    async def hoster_kb_close(_, m):
        await m.reply_text(small_caps("hoster menu closed."), reply_markup=ReplyKeyboardRemove())

    async def _ask_referral_link(reply_text, uid, gid):
        await users.update_one({"_id": uid}, {"$set": {"awaiting_referral_gid": gid}}, upsert=True)
        await reply_text(small_caps("now send the referral channel's @username or t.me link. i must already be admin there — that's how i can check if someone joined it."))

    @app.on_message(filters.private & filters.regex("^🔁 Referral System$"))
    async def hoster_kb_referral(_, m):
        return await m.reply_text(small_caps("referral system is temporarily disabled."))
        docs = await saved_channels.find({"owner_id": m.from_user.id}).sort("title", 1).to_list(length=10)
        if not docs:
            return await m.reply_text(small_caps("you have no saved channels yet. use /addch @channel first, then try again."))
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(
            c.get("title", "Channel"), callback_data=f"refgc:{c['channel_id']}"
        )] for c in docs])
        await m.reply_text(small_caps("which giveaway channel should the referral leaderboard post to?"), reply_markup=kb)

    @app.on_callback_query(filters.regex(r"^refgc:"))
    async def refgc_cb(_, q):
        cid = int(q.data.split(":", 1)[1])
        g = await giveaways.find_one({"channel_id": cid, "hoster_id": q.from_user.id, "status": "active", "type": "main"})
        if not g:
            return await q.answer(small_caps("no active giveaway on that channel. host one first with /host, then try again."), show_alert=True)
        await q.answer()
        await _ask_referral_link(q.message.reply_text, q.from_user.id, g["_id"])

    @app.on_message(filters.private & filters.text)
    async def referral_link_text(app, m):
        if m.text and m.text.startswith("/"):
            raise ContinuePropagation
        u = await users.find_one({"_id": m.from_user.id})
        gid = u.get("awaiting_referral_gid") if u else None
        if not gid:
            raise ContinuePropagation
        g = await giveaways.find_one({"_id": gid, "hoster_id": m.from_user.id, "status": "active"})
        if not g:
            await users.update_one({"_id": m.from_user.id}, {"$unset": {"awaiting_referral_gid": ""}})
            return await m.reply_text(small_caps("that giveaway is no longer active."))
        ident = m.text.strip().replace("https://t.me/", "").replace("http://t.me/", "").lstrip("@")
        try:
            chat = await app.get_chat(ident)
        except Exception:
            return await m.reply_text(small_caps("i couldn't find that channel. send the @username or t.me link again."))
        if str(chat.type).lower().split(".")[-1] != "channel":
            return await m.reply_text(small_caps("that is not a channel. send the @username or t.me link again."))
        bot = await app.get_me()
        if not await is_channel_admin(app, chat.id, bot.id):
            return await m.reply_text(small_caps("add me as an admin in that channel first, then send it again."))
        await giveaways.update_one({"_id": gid}, {"$set": {"referral_channel_id": chat.id, "referral_channel_title": chat.title}})
        await users.update_one({"_id": m.from_user.id}, {"$unset": {"awaiting_referral_gid": ""}})
        await refresh_referral_board(app, gid)
        await m.reply_text(small_caps("referral system is live! the leaderboard has been posted in your giveaway channel."))