from pyrogram import filters
from pyrogram.types import ChatMemberUpdated
from database.db import giveaways, participants, voters
from services.entry import refresh_entry
from services.mini import refresh_live
from utils.fonts import small_caps


def user_mention(user_id, name):
    """
    Creates a clickable Telegram mention for the user.
    """
    safe_name = name or "User"
    return f'<a href="tg://user?id={user_id}">{safe_name}</a>'


def register(app):
    @app.on_chat_member_updated()
    async def membership(app, update: ChatMemberUpdated):
        chat_id = update.chat.id
        new = update.new_chat_member
        old = update.old_chat_member

        uid = (new or old).user.id if (new or old) else None
        if not uid:
            return

        active = await giveaways.find(
            {
                "channel_id": chat_id,
                "status": "active",
            }
        ).to_list(length=20)

        if not active:
            return

        # ---------------------------------------------------------
        # BOT LOST ADMIN / WAS REMOVED
        # ---------------------------------------------------------
        me = await app.get_me()

        if uid == me.id:
            status = str(new.status).lower() if new else ""

            if "administrator" not in status and "owner" not in status:
                for g in active:
                    await giveaways.update_one(
                        {"_id": g["_id"]},
                        {
                            "$set": {
                                "status": "cancelled",
                                "cancel_reason": "bot lost channel access",
                            }
                        },
                    )

                    try:
                        await app.send_message(
                            g["hoster_id"],
                            f"⚠️ Giveaway {g['_id']} was cancelled because "
                            f"VoteZenBot lost admin access.",
                        )
                    except Exception:
                        pass

            return

        # ---------------------------------------------------------
        # USER LEFT / WAS KICKED / WAS BANNED
        # ---------------------------------------------------------
        status = str(new.status).lower() if new else ""

        if status not in ("left", "kicked", "banned"):
            return

        for g in active:

            # =====================================================
            # CASE A:
            # User had voted for another participant.
            # Remove their vote and notify the channel.
            # =====================================================
            v = await voters.find_one(
                {
                    "giveaway_id": g["_id"],
                    "voter_id": uid,
                }
            )

            if v:
                await voters.delete_one({"_id": v["_id"]})

                participant = await participants.find_one(
                    {
                        "giveaway_id": g["_id"],
                        "user_id": v["participant_id"],
                    }
                )

                if participant:
                    # Prevent vote_count from going below zero.
                    old_votes = max(0, participant.get("vote_count", 0))
                    new_votes = max(0, old_votes - 1)

                    await participants.update_one(
                        {"_id": participant["_id"]},
                        {"$set": {"vote_count": new_votes}},
                    )

                    participant["vote_count"] = new_votes

                    await refresh_entry(
                        app,
                        g,
                        participant,
                    )

                # -------------------------------------------------
                # CLICKABLE VOTER NAME + SMALL CAPS MESSAGE
                # -------------------------------------------------
                voter_name = v.get("voter_name") or None

                if not voter_name:
                    try:
                        user = await app.get_users(uid)
                        voter_name = user.first_name or "User"
                    except Exception:
                        voter_name = "User"

                mention = user_mention(uid, voter_name)

                notification = (
                    f"📢 {mention} "
                    f"{small_caps('left the channel')}\n"
                    f"🗳️ {small_caps('their vote has been removed')}\n"
                    f"{small_caps('this participant\'s vote count has been reduced by 1.')}"
                )

                try:
                    await app.send_message(
                        chat_id,
                        notification,
                        disable_web_page_preview=True,
                    )
                except Exception:
                    pass

            # =====================================================
            # CASE B:
            # User was themselves a participant.
            # Their own giveaway entry becomes invalid.
            # =====================================================
            own = await participants.find_one(
                {
                    "giveaway_id": g["_id"],
                    "user_id": uid,
                }
            )

            if own:

                # -------------------------------------------------
                # MAIN GIVEAWAY
                # -------------------------------------------------
                if g["type"] == "main":

                    if own.get("message_id"):
                        try:
                            await app.delete_messages(
                                chat_id,
                                own["message_id"],
                            )
                        except Exception:
                            pass

                    # Remove votes received by this participant.
                    await voters.delete_many(
                        {
                            "giveaway_id": g["_id"],
                            "participant_id": uid,
                        }
                    )

                    await participants.delete_one(
                        {"_id": own["_id"]}
                    )

                    name = own.get("name", "A participant")
                    mention = user_mention(uid, name)

                    try:
                        await app.send_message(
                            chat_id,
                            (
                                f"📢 {small_caps('participant left')}\n\n"
                                f"{mention} "
                                f"{small_caps('left the channel — their giveaway entry is no longer valid.')}"
                            ),
                            disable_web_page_preview=True,
                        )
                    except Exception:
                        pass

                # -------------------------------------------------
                # MINI GIVEAWAY
                # -------------------------------------------------
                else:

                    await participants.delete_one(
                        {"_id": own["_id"]}
                    )

                    mid = await refresh_live(
                        app,
                        g,
                    )

                    if mid and not g.get("live_message_id"):
                        await giveaways.update_one(
                            {"_id": g["_id"]},
                            {
                                "$set": {
                                    "live_message_id": mid
                                }
                            },
                        )

                    name = own.get("name", "A participant")
                    mention = user_mention(uid, name)

                    try:
                        await app.send_message(
                            chat_id,
                            (
                                f"📢 {small_caps('participant left')}\n\n"
                                f"{mention} "
                                f"{small_caps('left the channel — entry #')}"
                                f"{own.get('number', '?')} "
                                f"{small_caps('is no longer valid.')}"
                            ),
                            disable_web_page_preview=True,
                        )
                    except Exception:
                        pass 