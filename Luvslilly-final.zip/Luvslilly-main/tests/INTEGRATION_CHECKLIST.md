# VoteZenBot integration checklist

Run this only after adding real credentials.

1. `/start`, `/help`, startpic, broadcast and ban/unban.
2. `/addch`, `/channels`, `/delch`; verify bot + hoster are channel admins.
3. `/host`: channel → start/skip → end/skip → review → confirm.
4. Verify exactly one active VoteZenBot giveaway per channel.
5. Main deep link: membership gate → caption skip/text → PFP/fallback entry.
6. Vote: self-vote, first vote, same-entry toggle, different-entry rejection.
7. `/incr`: positive only; manual votes remain separate; real voter identity is never fabricated.
8. `/leaderboard` and `/mystats`.
9. `/banp` removes all giveaway activity; `/unbanp` allows fresh rejoin.
10. `/end` confirmation and automatic end after restart.
11. `/cancel` confirmation, including after participants exist; entry posts removed.
12. Mini: sequential numbering, live single message, truncation, winner count.
13. Mini random winners: unique winners, fewer entries than winner count, zero entries.
14. `/access` works only for owner/SAdmin; Admin cannot access.
15. `/access` participant button and `/exit`.
16. Bot losing admin rights cancels active giveaways and notifies hoster.
17. Voter leaving strips their vote; participant leaving invalidates their participation/votes as intended.
18. Deleted entry post: next vote/update recreates it with current data.
19. Result DM + channel result + TXT export.
20. Cleanup after 4 days leaves only lightweight giveaway summary.
