SMALL = {
"a":"ᴀ","b":"ʙ","c":"ᴄ","d":"ᴅ","e":"ᴇ","f":"ғ","g":"ɢ","h":"ʜ","i":"ɪ","j":"ᴊ",
"k":"ᴋ","l":"ʟ","m":"ᴍ","n":"ɴ","o":"ᴏ","p":"ᴘ","q":"ǫ","r":"ʀ","s":"s","t":"ᴛ",
"u":"ᴜ","v":"ᴠ","w":"ᴡ","x":"x","y":"ʏ","z":"ᴢ"
}
CAPS = {chr(65+i): chr(0x1D63C+i) for i in range(26)}
LOW = {chr(97+i): chr(0x1D656+i) for i in range(26)}
DIG = {str(i): chr(0x1D7EC+i) for i in range(10)}

def small_caps(text):
    return "".join(SMALL.get(ch.lower(), ch) for ch in text)

def heavy_channel(text):
    return "".join(CAPS.get(ch, LOW.get(ch, DIG.get(ch, ch))) for ch in text)
