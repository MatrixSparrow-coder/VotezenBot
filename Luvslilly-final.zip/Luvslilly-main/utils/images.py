import hashlib
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont

SIZE = 640
_COLORS = [
    (88, 101, 242), (237, 66, 69), (87, 242, 135),
    (250, 168, 26), (235, 69, 158), (35, 165, 89),
    (114, 137, 218), (240, 90, 90),
]
_FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
]


def _load_font(size):
    for path in _FONT_CANDIDATES:
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            continue
    return ImageFont.load_default()


def _to_square(img: Image.Image) -> Image.Image:
    w, h = img.size
    side = min(w, h)
    left = (w - side) // 2
    top = (h - side) // 2
    img = img.crop((left, top, left + side, top + side))
    return img.resize((SIZE, SIZE), Image.LANCZOS)


def process_profile_photo(raw_bytes: bytes) -> BytesIO:
    """Crop/resize a downloaded profile photo to a uniform square size."""
    img = Image.open(BytesIO(raw_bytes)).convert("RGB")
    img = _to_square(img)
    out = BytesIO()
    out.name = "entry.jpg"
    img.save(out, "JPEG", quality=90)
    out.seek(0)
    return out


def placeholder_image(name: str) -> BytesIO:
    """Deterministic colored placeholder (same size as real entries) for
    users without a visible profile photo, so every entry post looks
    consistent instead of falling back to a plain text message."""
    seed = (name or "U").strip() or "U"
    idx = int(hashlib.md5(seed.encode("utf-8")).hexdigest(), 16) % len(_COLORS)
    bg = _COLORS[idx]
    img = Image.new("RGB", (SIZE, SIZE), bg)
    draw = ImageDraw.Draw(img)
    letter = seed[0].upper()
    font = _load_font(SIZE // 2)
    bbox = draw.textbbox((0, 0), letter, font=font)
    w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
    draw.text(((SIZE - w) / 2 - bbox[0], (SIZE - h) / 2 - bbox[1]), letter, fill=(255, 255, 255), font=font)
    out = BytesIO()
    out.name = "entry.jpg"
    img.save(out, "JPEG", quality=90)
    out.seek(0)
    return out
