from datetime import datetime
import pytz

IST = pytz.timezone("Asia/Kolkata")
FMT = "%Y-%m-%d %H:%M"

def parse_ist(value):
    return IST.localize(datetime.strptime(value.strip(), FMT))

def display(dt):
    if not dt:
        return "sᴇᴛ ᴍᴀɴᴜᴀʟʟʏ"
    return dt.astimezone(IST).strftime("%d %b %Y • %I:%M %p IST")
