import re

# Escapes characters that have special meaning in Pyrogram's default Markdown
# parser. Any text that comes from a user (name, username, caption) MUST be
# passed through this before being interpolated into a message that uses
# markdown formatting elsewhere (bold headers, [mentions](tg://user?id=..), etc).
# Without this, a name/caption containing _ * ` [ ] breaks parsing and can
# crash the send/edit call entirely.
_MD_SPECIAL = re.compile(r"([_*`\[\]])")


def escape_md(text):
    if text is None:
        return ""
    return _MD_SPECIAL.sub(r"\\\1", str(text))
