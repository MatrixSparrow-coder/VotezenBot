from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from .fonts import small_caps

def yes_no(prefix):
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✓ " + small_caps("yes"), callback_data=f"{prefix}:yes"),
        InlineKeyboardButton("✕ " + small_caps("no"), callback_data=f"{prefix}:no"),
    ]])

def review(gid):
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✓ " + small_caps("confirm & create"), callback_data=f"review:{gid}:yes"),
        InlineKeyboardButton("✕ " + small_caps("cancel"), callback_data=f"review:{gid}:no"),
    ]])

def force_sub(url, gid):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ " + small_caps("join channel"), url=url)],
        [InlineKeyboardButton("✓ " + small_caps("i've joined, check again"), callback_data=f"recheck:{gid}")]
    ])

def vote(gid, pid, count=0):
    return InlineKeyboardMarkup([[
        InlineKeyboardButton(f"🗳️ {small_caps('vote')} ({count})", callback_data=f"vote:{gid}:{pid}")
    ]])

def skip_caption(gid):
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("⏭️ " + small_caps("skip"), callback_data=f"caption_skip:{gid}")
    ]])

def mini_join(url):
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("🎟️ " + small_caps("join now"), url=url)
    ]])

def referral_join(url, gid, referrer_id):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ " + small_caps("join channel"), url=url)],
        [InlineKeyboardButton("✓ " + small_caps("i've joined, check again"), callback_data=f"refcheck:{gid}:{referrer_id}")]
    ])

def download_export(gid):
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("📄 " + small_caps("download giveaway data"), callback_data=f"export:{gid}")
    ]])
